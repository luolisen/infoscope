# Display Events Contract v1

This directory is the only authoritative source for the MQTT Display Contract. The Infoscope application repository owns Event business data; ISD owns the versioned wire protocol that transports a display snapshot to a device.

## Delivery

| Field | Frozen value |
| --- | --- |
| Topic | `infoscope/v1/devices/{device_id}/events` |
| QoS | `1` |
| Retain | `true` |
| Event order | oldest to newest |
| Maximum Events | `12` |
| Device display | final three Events |
| Maximum serialized payload | `4096` UTF-8 bytes |
| Duplicate revision | ignore without rendering or animation |

Each device uses a distinct MQTT credential. Its ACL permits subscription only to its own Event topic. Publisher credentials are separate. Anonymous access and public broker exposure are prohibited.

## Field semantics

`schema` is exactly `infoscope.display.events.v1`. `revision` is opaque and compared byte-for-byte only for snapshot deduplication. `events` is already ordered oldest to newest by the producer.

For every Event:

- Before publishing, the Producer must trim `title` and collapse every run of Unicode whitespace—including spaces, tabs, and line breaks—to one ASCII space. The transmitted `title` is therefore already normalized and must contain 1–120 Unicode code points. Firmware may defensively repeat the same normalization, but must not use that behavior to accept a non-conforming Producer payload.
- `title` is the only field consumed by the A1 renderer.
- `id` is opaque metadata. A1 must not parse it or derive ordering or UI behavior from it.
- `state` is opaque metadata with no v1 enum. A1 must accept every non-empty string within the Schema limit and must not sort, filter, reject, decorate, or otherwise change UI based on its value.
- `display_time` is metadata and does not change A1 ordering.

The 4096-byte transport limit applies to the compact UTF-8 JSON serialization. A payload that exceeds it is rejected as a whole even if its decoded value otherwise matches the Schema.

## Versioning and repository boundary

After this reviewed Contract PR is merged, create the immutable `display-events-v1` tag at its merge commit. The tag must never move or be reused. Contract v1 is non-breaking-only: incompatible field, semantic, delivery, or limit changes require a new v2 Schema, fixture, tag, and review.

The Infoscope application repository must not keep a second authoritative Schema. A future, separately approved A2 publisher adapter may consume this exact tagged Contract. This Contract does not authorize that publisher, database/API changes, device binding, firmware, simulator, broker configuration, or a status topic.
