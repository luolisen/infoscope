"""Publish deterministic A1 physical-acceptance message sequences."""

from __future__ import annotations

import argparse
import time
from copy import deepcopy
from pathlib import Path

import paho.mqtt.client as mqtt

from simulator.contract import FIXTURE_PATH, encode_snapshot, event_topic, load_json
from simulator.publish_fixture import read_env_file


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument(
        "scenario",
        choices=[
            "latest-wins",
            "invalid",
            "oversized",
            "empty",
            "boundary-4096",
            "unsupported-glyph",
            "three-titles",
        ],
    )
    result.add_argument("--host", required=True)
    result.add_argument("--port", type=int, default=1883)
    result.add_argument("--device-id", required=True)
    result.add_argument("--env-file", type=Path, required=True)
    return result


def scenario_payloads(name: str) -> list[tuple[bytes, bool, float]]:
    if name == "invalid":
        return [(b'{"schema":', False, 0.0)]
    if name == "oversized":
        return [(b"x" * 4097, False, 0.0)]

    document = load_json(FIXTURE_PATH)
    if name == "empty":
        document["revision"] = "hardware-empty"
        document["events"] = []
        return [(encode_snapshot(document), True, 0.0)]
    if name == "three-titles":
        source = document["events"][0]
        titles = ["中文事件标题", "English update", "数字进展 2026"]
        document["revision"] = "hardware-three-titles"
        document["events"] = []
        for index, title in enumerate(titles, 1):
            event = deepcopy(source)
            event["id"] = f"hardware-{index}"
            event["title"] = title
            document["events"].append(event)
        return [(encode_snapshot(document), True, 0.0)]
    if name == "unsupported-glyph":
        document["revision"] = "hardware-unsupported-glyph"
        document["events"][0]["title"] = "未知🙂字形"
        return [(encode_snapshot(document), True, 0.0)]
    if name == "boundary-4096":
        source = document["events"][0]
        document["events"] = [deepcopy(source) for _ in range(12)]
        fields = [(document, "revision", 128)]
        for event in document["events"]:
            fields.extend(
                [(event, "id", 128), (event, "title", 120), (event, "state", 64)]
            )
        for target, key, maximum in fields:
            current = target[key]
            remaining = 4096 - len(encode_snapshot(document))
            if remaining <= 0:
                break
            target[key] = current + ("x" * min(remaining, maximum - len(current)))
        payload = encode_snapshot(document)
        if len(payload) != 4096:
            raise RuntimeError("failed to construct exact 4096-byte payload")
        return [(payload, False, 0.0)]

    middle = deepcopy(document)
    latest = deepcopy(document)
    middle["revision"] = "hardware-middle"
    middle["events"][0]["title"] = "动画中间页"
    latest["revision"] = "hardware-latest"
    latest["events"][0]["title"] = "动画最终页"
    return [
        (encode_snapshot(middle), True, 0.08),
        (encode_snapshot(latest), True, 0.0),
    ]


def main() -> None:
    args = parser().parse_args()
    credentials = read_env_file(args.env_file)
    username = credentials.get("INFOSCOPE_MQTT_USERNAME")
    password = credentials.get("INFOSCOPE_MQTT_PASSWORD")
    if not username or not password:
        raise SystemExit("env file must contain MQTT username and password")

    client = mqtt.Client(
        callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
        client_id="infoscope-display-hardware-scenario",
        protocol=mqtt.MQTTv311,
    )
    client.username_pw_set(username, password)
    client.connect(args.host, args.port, keepalive=30)
    client.loop_start()
    try:
        for payload, retain, delay_after in scenario_payloads(args.scenario):
            result = client.publish(
                event_topic(args.device_id), payload, qos=1, retain=retain
            )
            result.wait_for_publish(timeout=10)
            if not result.is_published():
                raise SystemExit("scenario publish timed out")
            if delay_after:
                time.sleep(delay_after)
    finally:
        client.disconnect()
        client.loop_stop()
    print(f"published hardware scenario {args.scenario}")


if __name__ == "__main__":
    main()
