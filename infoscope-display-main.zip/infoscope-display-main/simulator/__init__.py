"""Development-only publisher for the ISD Display Contract."""
