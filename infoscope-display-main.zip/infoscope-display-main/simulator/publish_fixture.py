"""Publish one validated retained Display Events v1 fixture."""

from __future__ import annotations

import argparse
import os
from pathlib import Path

import paho.mqtt.client as mqtt

from simulator.contract import FIXTURE_PATH, event_topic, load_and_encode


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--host", required=True)
    result.add_argument("--port", type=int, default=1883)
    result.add_argument("--device-id", required=True)
    result.add_argument("--fixture", type=Path, default=FIXTURE_PATH)
    result.add_argument("--env-file", type=Path)
    result.add_argument("--username", default=os.getenv("INFOSCOPE_MQTT_USERNAME"))
    result.add_argument("--client-id", default="infoscope-display-simulator")
    return result


def read_env_file(path: Path | None) -> dict[str, str]:
    if path is None:
        return {}
    values: dict[str, str] = {}
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise SystemExit(f"invalid env file line {line_number}")
        name, value = line.split("=", 1)
        if name not in {"INFOSCOPE_MQTT_USERNAME", "INFOSCOPE_MQTT_PASSWORD"}:
            raise SystemExit(f"unsupported env file key on line {line_number}")
        values[name] = value
    return values


def main() -> None:
    args = parser().parse_args()
    file_environment = read_env_file(args.env_file)
    username = args.username or file_environment.get("INFOSCOPE_MQTT_USERNAME")
    password = os.getenv("INFOSCOPE_MQTT_PASSWORD") or file_environment.get(
        "INFOSCOPE_MQTT_PASSWORD"
    )
    if not username or not password:
        raise SystemExit("set INFOSCOPE_MQTT_USERNAME and INFOSCOPE_MQTT_PASSWORD")

    payload = load_and_encode(args.fixture)
    topic = event_topic(args.device_id)
    client = mqtt.Client(
        callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
        client_id=args.client_id,
        protocol=mqtt.MQTTv311,
    )
    client.username_pw_set(username, password)
    client.connect(args.host, args.port, keepalive=30)
    client.loop_start()
    try:
        result = client.publish(topic, payload, qos=1, retain=True)
        result.wait_for_publish(timeout=10)
        if result.rc != mqtt.MQTT_ERR_SUCCESS or not result.is_published():
            raise SystemExit(f"publish failed with MQTT result {result.rc}")
    finally:
        client.disconnect()
        client.loop_stop()

    print(f"published {len(payload)} bytes to {topic} (qos=1 retain=true)")


if __name__ == "__main__":
    main()
