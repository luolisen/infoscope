"""Load and encode the authoritative Display Events v1 Contract."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker, ValidationError

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = REPOSITORY_ROOT / "contracts" / "mqtt" / "display-events-v1.schema.json"
FIXTURE_PATH = (
    REPOSITORY_ROOT / "contracts" / "mqtt" / "examples" / "display-events-v1.json"
)
MAX_PAYLOAD_BYTES = 4096
DEVICE_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")


class ContractError(ValueError):
    """A snapshot or device identifier violates Display Contract v1."""


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ContractError(f"unable to load JSON: {path}") from exc
    if not isinstance(value, dict):
        raise ContractError("snapshot root must be an object")
    return value


def contract_validator() -> Draft202012Validator:
    schema = load_json(SCHEMA_PATH)
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema, format_checker=FormatChecker())


def encode_snapshot(document: dict[str, Any]) -> bytes:
    try:
        contract_validator().validate(document)
    except ValidationError as exc:
        location = ".".join(str(part) for part in exc.absolute_path) or "root"
        raise ContractError(f"invalid snapshot at {location}: {exc.message}") from exc

    payload = json.dumps(document, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(payload) > MAX_PAYLOAD_BYTES:
        raise ContractError(
            f"serialized snapshot is {len(payload)} bytes; limit is {MAX_PAYLOAD_BYTES}"
        )
    return payload


def load_and_encode(path: Path = FIXTURE_PATH) -> bytes:
    return encode_snapshot(load_json(path))


def event_topic(device_id: str) -> str:
    if not DEVICE_ID_PATTERN.fullmatch(device_id):
        raise ContractError("device_id must match [A-Za-z0-9][A-Za-z0-9_-]{0,63}")
    return f"infoscope/v1/devices/{device_id}/events"
