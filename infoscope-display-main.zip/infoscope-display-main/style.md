# Infoscope Display — A1/A2 device UI baseline

Status: **A1 merged; A2 integration baseline proposed**. Exact matrices and timing are implemented, host-tested, and visually confirmed on both OLEDs.

Merged PR #5 proves the Event renderer and physical MQTT flows. The current implementation moves that renderer to software I²C and dedicates hardware I²C to the exact local-state sprite below.

## Fixed displays

- Sprite OLED: SSD1306 128×64 at `0x3C`, hardware I²C SDA GPIO 21 / SCL GPIO 22.
- Event OLED: SSD1306 128×64 at `0x3C`, software I²C SDA GPIO 25 / SCL GPIO 26. Its U8g2 software constructor receives `clock=26, data=25` in that order.
- Font: `u8g2_font_wqy12_t_gb2312` (12 px).
- Event baselines: Y `17`, `38`, `59`; X `0`.
- Exactly three rows. Fewer Events leave lower rows blank; newest Event is bottom row.
- Sprite source is 12×12 pixels, scaled 4× at X `46`, Y `4`; centered state label baseline Y `61`.
- No clock, weather, remote status topic, or Infoscope pipeline state in A1.

```text
OpenAI 发布新模型
低空经济试点扩大
SpaceX 完成新测试
```

## Text behavior

Collapse whitespace to one ASCII space. Truncate by rendered pixel width on a glyph boundary and append `…` (or `...` only when the font lacks ellipsis). Never horizontally scroll titles. Unsupported glyphs render as `?`; line coordinates never move.

## Screen states

| State | Presentation |
| --- | --- |
| Boot | centered `观澜启动中` |
| Wi-Fi connecting | centered `Wi-Fi 连接中` |
| MQTT connecting | centered `MQTT 连接中` |
| No Events | centered `暂无 Event` |
| Offline after valid data | retain rows; 6×6 outlined marker at top-right |
| Protocol error after valid data | retain rows; 6×6 filled marker for 3 seconds, then outlined marker |
| Protocol error without valid data | centered `消息格式错误` |

## Sprite screen

Local labels are `启动中`, `Wi-Fi 连接中`, `MQTT 连接中`, `在线`, `离线`, and `消息错误`. `#` is lit and `.` is unlit; every row is exactly 12 pixels. These are the complete source frames—no improvised or downloaded art.

```text
OPEN                 BLINK                NOD
....####....         ....####....         ............
...#....#...         ...#....#...         ....####....
..#.#..#.#..         ..#......#..         ...#....#...
..#......#..         ..#.####.#..         ..#.#..#.#..
..#.#..#.#..         ..#......#..         ..#......#..
..#......#..         ..#......#..         ..#.#..#.#..
...#....#...         ...#....#...         ..#......#..
....####....         ....####....         ...#....#...
.....##.....         .....##.....         ....####....
....#..#....         ....#..#....         .....##.....
...#....#...         ...#....#...         ....#..#....
............         ............         ...#....#...

SHAKE_LEFT           SHAKE_RIGHT          ERROR
...####.....         .....####...          ....####....
..#....#....         ....#....#..          ...#....#...
.#.#..#.#...         ...#.#..#.#.          ..#.#..#.#..
.#......#...         ...#.####.#.          ..#.####.#..
.#.#..#.#...         ...#......#.          ..#......#..
.#......#...         ...#.#..#.#.          ..#.####.#..
..#....#....         ....#....#..          ...#....#...
...####.....         .....####...          ....####....
....##......         ......##....          .....##.....
...#..#.....         .....#..#...          ....####....
..#....#....         ....#....#..          ...#....#...
............         ............          ............
```

At 50 ms ticks, boot/Wi-Fi/MQTT connecting runs `SHAKE_LEFT → OPEN → SHAKE_RIGHT → OPEN`, then holds `OPEN` 800 ms. Online holds `OPEN` 2200 ms, shows `BLINK` 100 ms, holds `OPEN` 2200 ms, then runs `OPEN → NOD → OPEN` at 150 ms per frame. Offline holds `BLINK`; protocol error holds `ERROR`. All timing uses `millis()`; no animation may block MQTT.

## Snapshot transition and refresh

First retained snapshot renders directly. New revision moves old page upward and new page from below: 8 px steps, 20 ms per step, about 180 ms total. Duplicate revision causes no redraw or animation. During a transition, firmware retains at most one pending complete valid snapshot; each newer valid revision replaces the older pending snapshot. When the transition ends, only the latest pending snapshot renders—intermediate revisions never replay.

Each OLED owns its own `clearBuffer → draw → sendBuffer` pass. Event animation never clears the sprite buffer, and sprite animation never clears Event content. The Event screen does not redraw unchanged content. The sprite redraws only on state/frame changes. No flashing or residual-frame behavior is permitted.

Hardware acceptance records both buses, boot, connection/offline/error sprite states, shake/blink/nod sequences, no-events, three-line page, transition, protocol-error-with-cache, and retained recovery.

## A2 UI invariants

Real Infoscope messages introduce no new screen or remote status indicator. The Event OLED renders only the latest three Contract `title` values with the existing normalization, font fallback, truncation, and upward transition. `id`, `state`, and `display_time` remain opaque metadata; a legal unknown value cannot alter the page, sprite, ordering, or error treatment.

The sprite remains exclusively device-local: boot, Wi-Fi/MQTT connection, online, offline, and protocol-error frames retain their exact A1 matrix and timing. A2 acceptance compares the Event page with the bound user's visible snapshot while separately checking that a second device cannot receive it.

The A2 handoff document must state that the API is upstream of MQTT and cannot add UI fields or remote sprite commands. Its acceptance screenshots/logs must identify only the test device and revision; user secrets, tokens, and private Event payloads must not be copied into the document.
