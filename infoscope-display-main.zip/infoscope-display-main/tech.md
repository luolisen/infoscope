# Infoscope Display — technical baseline

Status: **A1 merged; A2 integration baseline proposed**. Firmware has been uploaded, functionally exercised, and visually confirmed on both OLEDs.

## Only data path

```text
ISD Contract v1 fixture → Simulator Publisher → Authenticated Mosquitto
                                                    ↓
                                             ESP32 MQTT client
                                                    ↓
                              Size + Contract v1 field validation
                                                    ↓
                             Revision deduplication + in-memory snapshot
                                                    ↓
                              Software-I²C SSD1306 Event renderer

ESP32 local connection/protocol state → Hardware-I²C SSD1306 sprite renderer
```

The simulator is the only A1 producer. The ESP32 never reaches PostgreSQL, HTTP APIs, or the Infoscope repository.

## Pinned stack

| Layer | Choice |
| --- | --- |
| Build | Arduino CLI, not PlatformIO |
| Board core | `esp32:esp32@2.0.17` |
| MQTT | `256dpi/MQTT@2.5.3` |
| JSON | `ArduinoJson@6.21.5` |
| OLED | `U8g2@2.36.19` |
| Simulator | Python `3.12.3` + `paho-mqtt==2.1.0` |
| Broker | Eclipse Mosquitto `2.0.22` (`eclipse-mosquitto:2.0.22`) |

The dual-display implementation compiles with the pinned stack at 974,229 flash bytes (74%) and 53,584 bytes of global RAM (16%). It uploads successfully to an ESP32-D0WD-V3. The host suite has 55 passing tests, including the six exact sprite matrices, frozen animation timing, dual-bus constructor ordering, real Mosquitto authentication, ACL, normal-restart retained persistence, secret-safe password hashing, and C-header input rejection. `broker-dev/configure_local.py` creates ignored broker credentials, ACL, firmware configuration, and runtime paths without printing secrets or placing passwords in process arguments; the simulator can read its ignored credential file directly.

Use hardware I²C SDA GPIO 21 / SCL GPIO 22 for the sprite and software I²C SDA GPIO 25 / SCL GPIO 26 for Events. U8g2's software-I²C constructor orders the pins as `clock, data`, not `data, clock`; the frozen declarations are:

```cpp
U8G2_SSD1306_128X64_NONAME_F_HW_I2C spriteDisplay(U8G2_R0, U8X8_PIN_NONE);
U8G2_SSD1306_128X64_NONAME_F_SW_I2C eventDisplay(
    U8G2_R0, /* clock=*/26, /* data=*/25, U8X8_PIN_NONE);
```

Initialize the hardware bus with `Wire.begin(/* sda=*/21, /* scl=*/22)` and run it at 400 kHz. Both displays use address `0x3C`. The buses must not be joined and each needs effective pull-ups.

## Broker boundary

```conf
listener 1883 0.0.0.0
allow_anonymous false
password_file ./secrets/passwords
acl_file ./secrets/acl
persistence true
persistence_location ./data/
persistence_file mosquitto.db
```

`broker-dev/data/` is an ignored, fresh-clone-writable directory. A1 guarantees retained recovery only after a normal broker stop followed by restart; power-loss/crash durability is out of scope. Before each retained-recovery test, stop the broker and run `rm -f broker-dev/data/mosquitto.db`; then start the broker, publish the fixture retained, stop it normally, restart it, and subscribe the device. Credentials/ACLs are ignored local secrets. Each device account can subscribe only to `infoscope/v1/devices/{device_id}/events`; the simulator has a separate restricted publisher account. The broker is not Internet-exposed.

## State machine and validation

`WIFI_CONNECTING → MQTT_CONNECTING → ONLINE`; Wi-Fi loss returns to the first state, MQTT loss to the second. Reconnect backoff is exponential, capped at 30 seconds with deterministic jitter. `mqtt.loop()` runs in each connected loop iteration.

The same local state machine drives the sprite directly. Frames use `millis()` scheduling with a 50 ms minimum tick and their own framebuffer. Event and sprite renderers never clear or send each other's display buffer.

Callbacks copy a bounded payload and set a pending flag; parsing, validation, and rendering run in the main loop. First retained valid snapshot draws directly. Later revision triggers page transition. A snapshot applies only after all Contract v1 checks succeed. Firmware holds at most one pending valid snapshot while a transition is active; each newer valid revision replaces it. When the transition ends, it renders only that latest pending snapshot and never replays intermediate revisions.

| Resource | Limit |
| --- | --- |
| Event payload | 4096 bytes |
| MQTT receive buffer | 4608 bytes |
| JSON document capacity | 6144 bytes |
| Event records | 12 |
| Normalized source title | 120 code points |

The extra MQTT capacity covers fixed header, remaining-length encoding, topic bytes, QoS packet identifier, and 4096-byte payload. The JSON document capacity separately leaves room for parsed-object metadata. A test proves receipt of exactly 4096 bytes.

## Text, tests, and boundaries

`u8g2_font_wqy12_t_gb2312` supports ASCII, digits, punctuation, and GB2312 Chinese glyphs. Payload is UTF-8; unsupported glyphs become `?` with a bounded rendering warning. A1 does not claim full Unicode coverage.

Host tests cover canonical fixture regression, exact boundary size, ordering, duplicate revisions, malformed data, and pixel truncation. Broker tests prove anonymous and unauthorized-topic access fail, and normal-stop retained recovery passes from a cleaned data directory. Hardware tests record compile output, serial logs, retained recovery, Wi-Fi loss/recovery, and broker restart/recovery. A1.1 must add an exact Python dependency lock file; A1.2 must use the declared exact Mosquitto image tag in its documented launch command.

```text
infoscope-display/
├── plan.md tech.md style.md dev.md
├── contracts/mqtt/ # authoritative Display Contract Schema, fixture, and notes
├── firmware/       # ESP32 dual-display device code only
├── simulator/      # canonical-fixture publisher only
├── broker-dev/     # authenticated local config templates; `data/` ignored
└── tests/          # host-side device-contract tests
```

Secrets, artifacts, Arduino caches, broker password/ACL files, and serial logs are ignored. This repository owns and versions Display Contract v1. The existing `infoscope` repository may only consume a reviewed, tagged ISD Contract in a separately approved A2 publisher integration.

## Physical acceptance network

The primary adapter remains on the development network. A secondary USB Wi-Fi adapter hosts a 2.4 GHz, private `ISD-LAB` AP at `10.42.0.1`; the ESP32 receives `10.42.0.189`. `broker-dev/hardware_hotspot.py` refuses to reuse the primary interface and checks that its connection remains unchanged. Mosquitto remains authenticated and is not publicly forwarded. This topology has passed device authentication, QoS 1 delivery, broker restart, Wi-Fi loss/recovery, retained restore, and power-on restore.

## A2 integration handoff

```text
Infoscope personalized Event result
  → DisplaySnapshotService (Alan)
  → tagged display-events-v1 encoder (Alan)
  → authenticated private Mosquitto, per-device ACL (Alan)
  → unchanged ESP32 Contract consumer (Lingjiu)
  → software-I²C Event OLED + local hardware-I²C sprite
```

`infoscope` supplies only an A2-local MQTT endpoint, device ID, device credential, and user/device binding. They are written only to ignored local configuration; the ESP32 never receives a user ID, database credential, API token, or publisher credential. ISD supplies the immutable Contract tag and consumes the real topic exactly as in A1. Publisher tests live in `infoscope`; ISD tests consumption, authorization failure, retained restoration, and display equivalence.

At the A2.1 kickoff, before API code is written, `docs/a2-publisher-handoff.md` must be produced from this frozen boundary. It records the upstream input (`PersonalizedEvent`/visible snapshot), the publisher output (tagged Contract v1 JSON), branch names and merge order, environment-variable names without values, ACL provisioning steps, and the upstream/broker/device/physical test evidence owners. It is a handoff checklist, not a second schema or an API implementation.

No status topic is introduced. Publisher health, Worker state, and application phases never control the sprite. A2 does not add TLS, public broker access, OTA, alternative OLED hardware, or a Contract v1 change.
