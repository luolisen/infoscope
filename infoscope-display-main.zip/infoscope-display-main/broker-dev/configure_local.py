"""Create ignored authenticated broker and firmware configuration without printing secrets."""

from __future__ import annotations

import argparse
import re
import secrets
import shutil
import subprocess
import tempfile
import unicodedata
from pathlib import Path

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--wifi-header-source", type=Path, required=True)
    result.add_argument("--wifi-ssid", help="override only the source header SSID")
    result.add_argument("--mqtt-host", required=True)
    result.add_argument("--mqtt-port", type=int, default=1884)
    result.add_argument("--device-id", default="display-001")
    result.add_argument("--force", action="store_true", help="rotate existing local credentials")
    return result


def read_string_constant(source: str, name: str) -> str:
    patterns = [
        rf"#define\s+{name}\s+\"([^\"]+)\"",
        rf"constexpr\s+char\s+{name}(?:\[\])?\s*=\s*\"([^\"]+)\"\s*;",
    ]
    for pattern in patterns:
        match = re.search(pattern, source)
        if match:
            return match.group(1)
    raise ValueError(f"missing string constant {name}")


def c_string(value: str) -> str:
    for character in value:
        if unicodedata.category(character) == "Cc":
            raise ValueError(
                f"configuration value contains control character U+{ord(character):04X}"
            )
    return value.replace("\\", "\\\\").replace('"', '\\"')


def write_private(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")
    path.chmod(0o600)


def write_password_file(path: Path, credentials: list[tuple[str, str]]) -> None:
    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            delete=False,
        ) as temporary:
            temporary_path = Path(temporary.name)
            for username, password in credentials:
                temporary.write(f"{username}:{password}\n")
        temporary_path.chmod(0o600)
        subprocess.run(
            ["mosquitto_passwd", "-U", str(temporary_path)],
            check=True,
            capture_output=True,
            text=True,
        )
        temporary_path.chmod(0o600)
        temporary_path.replace(path)
        temporary_path = None
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


def main() -> None:
    args = parser().parse_args()
    source = args.wifi_header_source.read_text(encoding="utf-8")
    wifi_ssid = args.wifi_ssid or read_string_constant(source, "WIFI_SSID")
    wifi_password = read_string_constant(source, "WIFI_PASSWORD")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", args.device_id):
        raise SystemExit("invalid device ID")
    if not 1 <= args.mqtt_port <= 65535:
        raise SystemExit("MQTT port must be between 1 and 65535")
    try:
        escaped_wifi_ssid = c_string(wifi_ssid)
        escaped_wifi_password = c_string(wifi_password)
        escaped_mqtt_host = c_string(args.mqtt_host)
        escaped_device_id = c_string(args.device_id)
    except ValueError as error:
        raise SystemExit(str(error)) from error

    secrets_dir = REPOSITORY_ROOT / "broker-dev" / "secrets"
    data_dir = REPOSITORY_ROOT / "broker-dev" / "data"
    runtime_dir = REPOSITORY_ROOT / "broker-dev" / ".runtime"
    local_header = REPOSITORY_ROOT / "firmware" / "infoscope_display" / "include" / "local_config.h"
    protected_outputs = [
        secrets_dir / "passwords",
        secrets_dir / "acl",
        secrets_dir / "simulator.env",
        local_header,
        runtime_dir / "mosquitto.conf",
    ]
    if not args.force and any(path.exists() for path in protected_outputs):
        raise SystemExit("local configuration exists; use --force to rotate and then reflash")

    simulator_password = secrets.token_urlsafe(24)
    device_password = secrets.token_urlsafe(24)
    for directory in (secrets_dir, data_dir, runtime_dir):
        directory.mkdir(parents=True, exist_ok=True)

    password_file = secrets_dir / "passwords"
    write_password_file(
        password_file,
        [("simulator", simulator_password), (args.device_id, device_password)],
    )
    acl_file = secrets_dir / "acl"
    write_private(
        acl_file,
        "\n".join(
            [
                "user simulator",
                f"topic write infoscope/v1/devices/{args.device_id}/events",
                "",
                f"user {args.device_id}",
                f"topic read infoscope/v1/devices/{args.device_id}/events",
                "",
            ]
        ),
    )
    write_private(
        secrets_dir / "simulator.env",
        "\n".join(
            [
                "INFOSCOPE_MQTT_USERNAME=simulator",
                f"INFOSCOPE_MQTT_PASSWORD={simulator_password}",
                "",
            ]
        ),
    )

    write_private(
        local_header,
        "\n".join(
            [
                "#pragma once",
                "",
                f'constexpr char WIFI_SSID[] = "{escaped_wifi_ssid}";',
                f'constexpr char WIFI_PASSWORD[] = "{escaped_wifi_password}";',
                f'constexpr char MQTT_HOST[] = "{escaped_mqtt_host}";',
                f"constexpr uint16_t MQTT_PORT = {args.mqtt_port};",
                f'constexpr char MQTT_USERNAME[] = "{escaped_device_id}";',
                f'constexpr char MQTT_PASSWORD[] = "{c_string(device_password)}";',
                f'constexpr char DEVICE_ID[] = "{escaped_device_id}";',
                "",
            ]
        ),
    )

    broker_binary = shutil.which("mosquitto")
    if broker_binary is None:
        raise SystemExit("mosquitto 2.0.22 is required")
    broker_help = subprocess.run(
        [broker_binary, "-h"],
        check=True,
        capture_output=True,
        text=True,
    )
    if "mosquitto version 2.0.22" not in broker_help.stdout:
        raise SystemExit("mosquitto 2.0.22 is required")
    runtime_binary = runtime_dir / "mosquitto"
    shutil.copy2(broker_binary, runtime_binary)
    runtime_binary.chmod(0o700)
    runtime_config = runtime_dir / "mosquitto.conf"
    runtime_config.write_text(
        "\n".join(
            [
                f"listener {args.mqtt_port} 0.0.0.0",
                "allow_anonymous false",
                f"password_file {password_file}",
                f"acl_file {acl_file}",
                "persistence true",
                f"persistence_location {data_dir}/",
                "persistence_file mosquitto.db",
                "log_dest stdout",
                "log_type error",
                "log_type warning",
                "log_type notice",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print("local broker and firmware configuration created; secrets were not printed")


if __name__ == "__main__":
    main()
