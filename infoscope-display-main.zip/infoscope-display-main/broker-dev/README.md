# Authenticated A1 development broker

The committed configuration uses the exact `eclipse-mosquitto:2.0.22` image. It listens on the LAN, rejects anonymous clients, separates publisher/device credentials, restricts the device to its own Event topic, and persists retained messages under ignored `broker-dev/data/`.

Create local secrets without committing them:

```bash
mkdir -p broker-dev/secrets broker-dev/data
mosquitto_passwd -c broker-dev/secrets/passwords simulator
mosquitto_passwd broker-dev/secrets/passwords display-001
cp broker-dev/acl.example broker-dev/secrets/acl
docker compose -f broker-dev/compose.yaml up -d
```

For a clean retained-recovery test, stop the broker normally and remove only its ignored database before starting again:

```bash
docker compose -f broker-dev/compose.yaml down
rm -f broker-dev/data/mosquitto.db
```

Publish with `simulator/publish_fixture.py`; the device account must never have write permission. Do not forward port 1883 to the public Internet. Passwords, the generated ACL, broker data, and logs remain local.

For local hardware development without Docker, `configure_local.py` can migrate Wi-Fi values from an existing ignored header, generate fresh MQTT credentials, prepare the ignored firmware header, and copy the installed Mosquitto 2.0.22 binary into an ignored runtime directory. It never prints generated secrets:

```bash
uv run python broker-dev/configure_local.py \
  --wifi-header-source /path/to/existing/wifi_config.h \
  --mqtt-host 192.0.2.10 \
  --mqtt-port 1884
broker-dev/.runtime/mosquitto -c broker-dev/.runtime/mosquitto.conf
```

The tool refuses to overwrite an existing local configuration. Pass `--force` only to rotate credentials, and immediately rebuild/reflash the device afterward so its credential matches the broker.
When a secondary adapter hosts a test AP with the same local password source, pass `--wifi-ssid ISD-LAB` to override only the SSID written to the ignored firmware configuration.
Generated broker passwords are passed through a mode-`0600` temporary file and hashed with `mosquitto_passwd -U`; passwords never enter process arguments. Values written to the C header reject control characters before any output is created.

For physical acceptance, a secondary Wi-Fi adapter can host an isolated AP while the primary adapter keeps the development network online. The helper refuses to reuse the primary interface and verifies that its connection remains unchanged:

```bash
uv run python broker-dev/hardware_hotspot.py start \
  --interface wlxSECONDARY \
  --primary-interface wlpPRIMARY \
  --ssid ISD-LAB \
  --password-source /path/to/ignored/wifi_config.h

# After hardware acceptance:
uv run python broker-dev/hardware_hotspot.py stop --interface wlxSECONDARY
```
