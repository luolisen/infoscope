"""Manage an isolated hardware-test AP on a secondary Wi-Fi adapter."""

from __future__ import annotations

import argparse
import re
import subprocess
from pathlib import Path

CONNECTION_NAME = "isd-hardware"


def read_string_constant(path: Path, name: str) -> str:
    source = path.read_text(encoding="utf-8")
    patterns = [
        rf"#define\s+{name}\s+\"([^\"]+)\"",
        rf"constexpr\s+char\s+{name}(?:\[\])?\s*=\s*\"([^\"]+)\"\s*;",
    ]
    for pattern in patterns:
        match = re.search(pattern, source)
        if match:
            return match.group(1)
    raise ValueError(f"missing string constant {name}")


def nmcli(arguments: list[str], *, check: bool = True) -> str:
    result = subprocess.run(
        ["nmcli", *arguments],
        check=check,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def active_connection(interface: str) -> str:
    return nmcli(["-g", "GENERAL.CONNECTION", "device", "show", interface])


def start(interface: str, primary_interface: str, ssid: str, password_source: Path) -> None:
    if interface == primary_interface:
        raise SystemExit("test and primary interfaces must differ")
    primary_before = active_connection(primary_interface)
    if not primary_before or primary_before == "--":
        raise SystemExit("primary network is not connected")
    password = read_string_constant(password_source, "WIFI_PASSWORD")
    nmcli(["connection", "delete", CONNECTION_NAME], check=False)
    nmcli(
        [
            "device",
            "wifi",
            "hotspot",
            "ifname",
            interface,
            "con-name",
            CONNECTION_NAME,
            "ssid",
            ssid,
            "password",
            password,
        ]
    )
    if active_connection(interface) != CONNECTION_NAME:
        raise SystemExit("test hotspot did not remain active")
    if active_connection(primary_interface) != primary_before:
        nmcli(["connection", "delete", CONNECTION_NAME], check=False)
        raise SystemExit("primary network changed; test hotspot rolled back")
    print(f"hotspot {ssid} active on {interface}; primary network unchanged")


def stop(interface: str) -> None:
    nmcli(["connection", "delete", CONNECTION_NAME], check=False)
    nmcli(["device", "disconnect", interface], check=False)
    print(f"removed {CONNECTION_NAME} from {interface}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    start_parser = subparsers.add_parser("start")
    start_parser.add_argument("--interface", required=True)
    start_parser.add_argument("--primary-interface", required=True)
    start_parser.add_argument("--ssid", default="ISD-LAB")
    start_parser.add_argument("--password-source", type=Path, required=True)
    stop_parser = subparsers.add_parser("stop")
    stop_parser.add_argument("--interface", required=True)
    args = parser.parse_args()
    if args.command == "start":
        start(args.interface, args.primary_interface, args.ssid, args.password_source)
    else:
        stop(args.interface)


if __name__ == "__main__":
    main()
