# Infoscope Display — A1/A2 baseline

Status: **A1 merged; A2 integration baseline proposed**. Phase 0.5 is complete: the reviewed Contract v1 is tagged at `display-events-v1` (`82aa41731d8c973c4f498d704443e6e913ef155e`). Automated, serial-backed, and human OLED checks pass; `a1-hardware-verified` remains uncreated.

Implementation snapshot (2026-08-18): merged PR #7 completes Event output on the software-I²C OLED and the frozen local-state sprite on the hardware-I²C OLED. A2 changes only the message producer; Contract v1 and device presentation stay unchanged.

## Product and boundary

**Infoscope Display** is a repeatable LAN-only ESP32 terminal. It displays the newest three retained Event titles on one OLED while a separate OLED renders an animated local-state sprite.

Phase A1 validates authenticated MQTT, Contract v1 parsing, Chinese rendering, animation, revision deduplication, reconnect, and retained recovery. It does not access an API, database, Worker, or real Event pipeline.

## Frozen A1 hardware

| Item | Baseline |
| --- | --- |
| Board | ESP32 DevKit (ESP32-D0WD class) |
| Sprite display | SSD1306 128×64, `0x3C`, hardware I²C SDA GPIO 21 / SCL GPIO 22 |
| Event display | SSD1306 128×64, `0x3C`, software I²C SDA GPIO 25 / SCL GPIO 26 |
| Power | 3.3 V and GND |
| Sprite content | local boot/Wi-Fi/MQTT/offline/protocol state and frozen animation |
| Event content | newest 3 Event titles |

Both fixed-address modules stay on electrically separate SDA/SCL buses; only 3.3 V and GND are shared. The sprite is driven only by device-local state. No status MQTT topic or Infoscope pipeline mapping is added.

## Canonical Contract prerequisite

`SCOUT-Infoscope/infoscope-display` is the sole Contract v1 source for display-device delivery. Before A1.1, a reviewed ISD Contract PR must merge `contracts/mqtt/display-events-v1.schema.json`, `contracts/mqtt/examples/display-events-v1.json`, Contract validation tests, and MQTT architecture notes, then create the immutable `display-events-v1` tag.

The Schema and canonical fixture live directly in this repository and are consumed by its simulator and tests. ISD does not copy backend ordering logic. The existing `infoscope` repository must not create a second authoritative Display Contract; a later A2 publisher adapter consumes a reviewed, tagged ISD Contract version.

## Contract v1 delivery

| Field | Value |
| --- | --- |
| Topic | `infoscope/v1/devices/{device_id}/events` |
| QoS / retain | `1` / `true` |
| Event order | oldest → newest |
| Maximum Events | 12 |
| Displayed Events | final 3 |
| Event payload | at most 4096 UTF-8 bytes |
| Duplicate revision | ignore, no animation |

Expected fixture shape; the reviewed ISD Contract schema is authoritative:

```json
{
  "schema": "infoscope.display.events.v1",
  "revision": "01K2M0J4C6SFYF62W5RK4C9KZE",
  "generated_at": "2026-08-17T20:00:00+08:00",
  "events": [{"id": "f93acbb8-0000-4000-8000-000000000001", "title": "OpenAI 发布新模型", "state": "developing", "display_time": "2026-08-17T19:50:00+08:00"}]
}
```

Each device has a unique MQTT credential and ACL limited to its topic. The broker is LAN-only and authenticated; anonymous access and public exposure are prohibited.

## Device behavior

| Situation | Required behavior |
| --- | --- |
| First start | startup, then Wi-Fi/MQTT connecting; no stale content exists |
| First retained valid snapshot | render newest three directly, no arrival animation |
| New valid revision | push prior page upward over about 180 ms, then hold new page |
| Duplicate revision | leave page unchanged |
| Empty valid events | show `暂无 Event` |
| Invalid/oversized payload | retain prior valid page; protocol-error marker; never reboot |
| Wi-Fi/MQTT loss after valid data | retain page and show offline marker |
| Reconnect | subscribe again; retained snapshot restores page |

The hardware-I²C sprite remains responsive during Event operation and reflects only `boot`, Wi-Fi connecting, MQTT connecting, online, offline, or protocol error. It never consumes or mutates Event data.

## Limits, secrets, and logs

- 0–12 Events; source title ≤120 Unicode code points after whitespace normalization.
- Wi-Fi/MQTT host, credentials, and device ID are local ignored configuration; only a template enters Git.
- Logs include state, byte count, accepted revision, and bounded rejection reason—never secrets or raw payload.

## Definition of Done

1. A fresh `infoscope-display` clone builds firmware and runs its authenticated broker/simulator from the repository's canonical fixture.
2. The software-I²C OLED shows Chinese, English, and numeric titles in three rows while the hardware-I²C OLED shows the frozen sprite motions.
3. Exactly 4096-byte valid Event payload succeeds; invalid data preserves valid content.
4. Ordering, retained recovery, reconnect, and revision deduplication work as specified.
5. New revisions animate upward; duplicates do not animate.
6. Automated tests and a physical acceptance record pass.

Merged PR #7 completes all A1 Definition-of-Done checks. No `a1-hardware-verified` tag has been created.

## Not in A1

No Infoscope application changes, real publisher, a second authoritative Contract in `infoscope`, status topic, remote status mapping, TLS, public MQTT, anonymous broker, OTA, cloud/mobile app, SH1106, weather/clock, PCB, enclosure, or A2 work.

## Phase A2 — real Infoscope delivery

A2 connects the existing Infoscope application's device-bound Event snapshot to this terminal. The immutable `display-events-v1` Contract stays the only wire protocol: `infoscope/v1/devices/{device_id}/events`, QoS 1, retained, and existing size limits. OLED roles, title ordering, and all local sprite states are unchanged.

| Responsibility | Owner | Requirement |
| --- | --- | --- |
| Device binding and visible Event selection | Alan / `infoscope` | Reuse personalized results; never let the ESP32 read an API or database. |
| Snapshot and MQTT publisher | Alan / `infoscope` | Publish valid tagged Contract v1 retained QoS 1 only to the bound device topic. |
| Contract consumer and OLEDs | Lingjiu / ISD | Keep A1 validation, deduplication, reconnect, and local-only sprite behavior unchanged. |
| Joint acceptance | Alan + Lingjiu | Prove a user's visible snapshot reaches only that user's bound device and restores after restart. |

Unknown legal `event.state` remains opaque metadata: the terminal consumes only `title` and must not sort, filter, reject, or change UI from it. A different device account must be unable to subscribe to this device's topic.

Before Alan starts the A2.1 Publisher API branch, create `docs/a2-publisher-handoff.md` for the cross-repository handoff. It must teach the API input/output boundary, branch and merge order, immutable Contract tag/commit, device-topic and credential provisioning, upstream-to-device test ownership, and the exact joint-test evidence to return. The handoff document is written only after PR #8's A2 boundary is accepted; it must not invent a new payload or API endpoint.

### A2 Definition of Done

1. A real personalized snapshot reaches the correct device topic using the reviewed Contract tag.
2. The ESP32 retains existing Event behavior and keeps the sprite local-only.
3. The newest three displayed titles equal the bound user's visible snapshot; another device cannot read them.
4. Worker, broker, Wi-Fi, and ESP32 restart restore the retained page without duplicate animation for an unchanged revision.
5. Both repositories retain automated and physical joint-acceptance evidence; Contract v1 is unchanged.
