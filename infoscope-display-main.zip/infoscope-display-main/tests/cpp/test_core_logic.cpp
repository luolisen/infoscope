#include <assert.h>
#include <stdint.h>
#include <string.h>

#include "core_logic.h"

int main() {
  assert(isd::nextBackoffMs(0, 0) == 1000);
  assert(isd::nextBackoffMs(1, 0) >= 2000);
  assert(isd::nextBackoffMs(20, 500) == isd::BACKOFF_MAX_MS);
  assert(isd::nextBackoffMs(3, 42) == isd::nextBackoffMs(3, 42));
  assert(isd::incrementFailure(0) == 1);
  assert(isd::incrementFailure(UINT8_MAX) == UINT8_MAX);

  assert(!isd::timeReached(99, 100));
  assert(isd::timeReached(100, 100));
  assert(isd::timeReached(5, UINT32_MAX - 5));

  assert(isd::validCalendarDate(2024, 2, 29));
  assert(!isd::validCalendarDate(2026, 2, 29));
  assert(!isd::validCalendarDate(2026, 2, 31));
  assert(!isd::validCalendarDate(0, 1, 1));
  assert(!isd::validCalendarDate(2026, 13, 1));

  assert(isd::validDeviceId("display-001"));
  assert(isd::validDeviceId("D_1"));
  assert(!isd::validDeviceId(""));
  assert(!isd::validDeviceId("-display"));
  assert(!isd::validDeviceId("display/other"));
  assert(!isd::validDeviceId("display+#"));
  assert(!isd::validDeviceId(
      "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));

  for (uint8_t frame = 0; frame < 6; ++frame) {
    uint16_t litPixels = 0;
    for (uint8_t row = 0; row < 12; ++row) {
      assert(strlen(isd::SPRITE_PIXELS[frame][row]) == 12);
      for (uint8_t column = 0; column < 12; ++column) {
        char pixel = isd::SPRITE_PIXELS[frame][row][column];
        assert(pixel == '#' || pixel == '.');
        if (pixel == '#') ++litPixels;
      }
    }
    assert(litPixels > 0);
  }

  using isd::SpriteFrame;
  using isd::SpriteState;
  assert(isd::spriteFrameAt(SpriteState::BOOT, 0) == SpriteFrame::SHAKE_LEFT);
  assert(isd::spriteFrameAt(SpriteState::WIFI_CONNECTING, 49) ==
         SpriteFrame::SHAKE_LEFT);
  assert(isd::spriteFrameAt(SpriteState::MQTT_CONNECTING, 50) == SpriteFrame::OPEN);
  assert(isd::spriteFrameAt(SpriteState::BOOT, 100) == SpriteFrame::SHAKE_RIGHT);
  assert(isd::spriteFrameAt(SpriteState::BOOT, 150) == SpriteFrame::OPEN);
  assert(isd::spriteFrameAt(SpriteState::BOOT, 1000) == SpriteFrame::SHAKE_LEFT);

  assert(isd::spriteFrameAt(SpriteState::ONLINE, 0) == SpriteFrame::OPEN);
  assert(isd::spriteFrameAt(SpriteState::ONLINE, 2199) == SpriteFrame::OPEN);
  assert(isd::spriteFrameAt(SpriteState::ONLINE, 2200) == SpriteFrame::BLINK);
  assert(isd::spriteFrameAt(SpriteState::ONLINE, 2300) == SpriteFrame::OPEN);
  assert(isd::spriteFrameAt(SpriteState::ONLINE, 4650) == SpriteFrame::NOD);
  assert(isd::spriteFrameAt(SpriteState::ONLINE, 4800) == SpriteFrame::OPEN);
  assert(isd::spriteFrameAt(SpriteState::OFFLINE, 999999) == SpriteFrame::BLINK);
  assert(isd::spriteFrameAt(SpriteState::PROTOCOL_ERROR, 999999) ==
         SpriteFrame::ERROR);
}
