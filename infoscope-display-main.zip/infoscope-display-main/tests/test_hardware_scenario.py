from simulator.run_hardware_scenario import scenario_payloads


def test_latest_wins_scenario_has_two_valid_retained_revisions() -> None:
    payloads = scenario_payloads("latest-wins")

    assert len(payloads) == 2
    assert b'"revision":"hardware-middle"' in payloads[0][0]
    assert b'"revision":"hardware-latest"' in payloads[1][0]
    assert payloads[0][1] is True
    assert payloads[1][1] is True
    assert payloads[0][2] > 0


def test_invalid_and_oversized_scenarios_are_not_retained() -> None:
    invalid = scenario_payloads("invalid")[0]
    oversized = scenario_payloads("oversized")[0]

    assert invalid[1] is False
    assert len(oversized[0]) == 4097
    assert oversized[1] is False


def test_boundary_scenario_is_exactly_4096_bytes() -> None:
    payload, retain, _ = scenario_payloads("boundary-4096")[0]

    assert len(payload) == 4096
    assert retain is False


def test_three_title_scenario_has_ordered_display_rows() -> None:
    payload, retain, _ = scenario_payloads("three-titles")[0]

    assert payload.index("中文事件标题".encode()) < payload.index(b"English update")
    assert payload.index(b"English update") < payload.index("数字进展 2026".encode())
    assert retain is True
