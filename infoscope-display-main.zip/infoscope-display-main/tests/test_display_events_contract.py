"""Validation tests for the authoritative MQTT Display Contract v1."""

from __future__ import annotations

import json
from collections.abc import Callable
from copy import deepcopy
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator, FormatChecker, ValidationError

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = REPOSITORY_ROOT / "contracts" / "mqtt" / "display-events-v1.schema.json"
FIXTURE_PATH = (
    REPOSITORY_ROOT / "contracts" / "mqtt" / "examples" / "display-events-v1.json"
)
MAX_PAYLOAD_BYTES = 4096


def load_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def serialized_size(document: dict[str, object]) -> int:
    payload = json.dumps(document, ensure_ascii=False, separators=(",", ":"))
    return len(payload.encode("utf-8"))


def normalize_title(source: str) -> str:
    return " ".join(source.split())


@pytest.fixture
def validator() -> Draft202012Validator:
    schema = load_json(SCHEMA_PATH)
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema, format_checker=FormatChecker())


def test_canonical_fixture_validates_and_fits_transport_limit(
    validator: Draft202012Validator,
) -> None:
    fixture = load_json(FIXTURE_PATH)

    validator.validate(fixture)
    assert serialized_size(fixture) <= MAX_PAYLOAD_BYTES


def test_unknown_opaque_metadata_values_are_valid(
    validator: Draft202012Validator,
) -> None:
    fixture = load_json(FIXTURE_PATH)
    event = fixture["events"][0]  # type: ignore[index]
    event["id"] = "producer-specific:opaque-id"  # type: ignore[index]
    event["state"] = "future-state-not-known-to-a1"  # type: ignore[index]

    validator.validate(fixture)


@pytest.mark.parametrize(
    ("source", "normalized"),
    [
        ("  前后空白  ", "前后空白"),
        ("连续   ASCII    空格", "连续 ASCII 空格"),
        ("换行\n与\t制表符", "换行 与 制表符"),
    ],
)
def test_producer_normalizes_whitespace_before_publish(
    validator: Draft202012Validator,
    source: str,
    normalized: str,
) -> None:
    fixture = load_json(FIXTURE_PATH)
    event = fixture["events"][0]  # type: ignore[index]

    assert normalize_title(source) == normalized
    event["title"] = normalized  # type: ignore[index]
    validator.validate(fixture)

    event["title"] = source  # type: ignore[index]
    with pytest.raises(ValidationError):
        validator.validate(fixture)


def test_normalized_title_accepts_exactly_120_code_points(
    validator: Draft202012Validator,
) -> None:
    fixture = load_json(FIXTURE_PATH)
    event = fixture["events"][0]  # type: ignore[index]
    event["title"] = normalize_title(" \t" + ("界" * 120) + "\n ")  # type: ignore[index]

    validator.validate(fixture)
    assert len(event["title"]) == 120  # type: ignore[arg-type,index]


def test_normalized_title_rejects_more_than_120_code_points(
    validator: Draft202012Validator,
) -> None:
    fixture = load_json(FIXTURE_PATH)
    event = fixture["events"][0]  # type: ignore[index]
    event["title"] = normalize_title(" " + ("界" * 121) + " ")  # type: ignore[index]

    with pytest.raises(ValidationError):
        validator.validate(fixture)


Mutator = Callable[[dict[str, object]], None]


@pytest.mark.parametrize(
    "mutate",
    [
        lambda document: document.pop("revision"),
        lambda document: document.__setitem__("schema", "infoscope.display.events.v0"),
        lambda document: document.__setitem__("events", [{}] * 13),
        lambda document: document["events"][0].__setitem__("title", "x" * 121),  # type: ignore[index]
        lambda document: document.__setitem__("unexpected", True),
    ],
)
def test_contract_rejects_invalid_snapshots(
    validator: Draft202012Validator,
    mutate: Mutator,
) -> None:
    document = deepcopy(load_json(FIXTURE_PATH))
    mutate(document)

    with pytest.raises(ValidationError):
        validator.validate(document)


def test_valid_snapshot_can_reach_exact_4096_byte_boundary(
    validator: Draft202012Validator,
) -> None:
    fixture = load_json(FIXTURE_PATH)
    event = fixture["events"][0]  # type: ignore[index]
    fixture["events"] = [deepcopy(event) for _ in range(12)]

    fields: list[tuple[dict[str, object], str, int]] = [(fixture, "revision", 128)]
    for item in fixture["events"]:  # type: ignore[union-attr]
        fields.extend([(item, "id", 128), (item, "title", 120), (item, "state", 64)])

    for document, key, maximum in fields:
        current = document[key]
        assert isinstance(current, str)
        remaining = MAX_PAYLOAD_BYTES - serialized_size(fixture)
        if remaining <= 0:
            break
        document[key] = current + ("x" * min(remaining, maximum - len(current)))

    validator.validate(fixture)
    assert serialized_size(fixture) == MAX_PAYLOAD_BYTES
