from __future__ import annotations

import importlib.util
from pathlib import Path
from types import ModuleType


def load_broker_module(name: str) -> ModuleType:
    path = Path(__file__).resolve().parents[1] / "broker-dev" / f"{name}.py"
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
