from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import pytest

from simulator.contract import (
    ContractError,
    encode_snapshot,
    event_topic,
    load_json,
)

FIXTURE_PATH = (
    Path(__file__).resolve().parents[1]
    / "contracts"
    / "mqtt"
    / "examples"
    / "display-events-v1.json"
)


def fixture_document() -> dict[str, object]:
    return load_json(FIXTURE_PATH)


def test_canonical_fixture_encodes_as_compact_utf8() -> None:
    payload = encode_snapshot(fixture_document())

    assert payload.startswith(b'{"schema":"infoscope.display.events.v1"')
    assert "OpenAI 发布新模型".encode() in payload
    assert b"\n" not in payload


def test_encoder_preserves_contract_event_order() -> None:
    document = fixture_document()
    event = document["events"][0]  # type: ignore[index]
    older = deepcopy(event)
    newer = deepcopy(event)
    older["id"] = "old"  # type: ignore[index]
    older["title"] = "旧事件"  # type: ignore[index]
    newer["id"] = "new"  # type: ignore[index]
    newer["title"] = "新事件"  # type: ignore[index]
    document["events"] = [older, newer]

    payload = encode_snapshot(document)

    assert payload.index("旧事件".encode()) < payload.index("新事件".encode())


def test_encoder_accepts_unknown_opaque_state() -> None:
    document = fixture_document()
    document["events"][0]["state"] = "future-state"  # type: ignore[index]

    encode_snapshot(document)


@pytest.mark.parametrize("title", [" leading", "trailing ", "two  spaces", "tab\there"])
def test_encoder_rejects_non_normalized_wire_title(title: str) -> None:
    document = fixture_document()
    document["events"][0]["title"] = title  # type: ignore[index]

    with pytest.raises(ContractError, match="invalid snapshot"):
        encode_snapshot(document)


def test_encoder_rejects_valid_schema_document_over_transport_limit() -> None:
    document = fixture_document()
    source = document["events"][0]  # type: ignore[index]
    events = []
    for index in range(12):
        event = deepcopy(source)
        event["id"] = f"{index:02d}" + ("i" * 126)  # type: ignore[index]
        event["title"] = "t" * 120  # type: ignore[index]
        event["state"] = "s" * 64  # type: ignore[index]
        events.append(event)
    document["revision"] = "r" * 128
    document["events"] = events

    with pytest.raises(ContractError, match="limit is 4096"):
        encode_snapshot(document)


@pytest.mark.parametrize(
    "device_id",
    ["display-001", "display_001", "D1"],
)
def test_event_topic_accepts_safe_device_ids(device_id: str) -> None:
    assert event_topic(device_id) == f"infoscope/v1/devices/{device_id}/events"


@pytest.mark.parametrize("device_id", ["", "/", "device/other", "+", "#", "a" * 65])
def test_event_topic_rejects_wildcards_and_topic_injection(device_id: str) -> None:
    with pytest.raises(ContractError, match="device_id"):
        event_topic(device_id)
