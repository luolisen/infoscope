from __future__ import annotations

import shutil
import stat
import subprocess
from pathlib import Path

import pytest
from broker_dev_loader import load_broker_module

configure_local = load_broker_module("configure_local")


def test_c_string_escapes_quotes_and_backslashes() -> None:
    assert configure_local.c_string('safe\\"value') == 'safe\\\\\\"value'


@pytest.mark.parametrize("control", ["\n", "\r", "\0", "\x1f", "\x7f", "\x85"])
def test_c_string_rejects_control_characters(control: str) -> None:
    with pytest.raises(ValueError, match="control character"):
        configure_local.c_string(f"before{control}after")


def test_password_file_hashes_without_passwords_in_argv(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    destination = tmp_path / "passwords"
    observed_argv: list[str] = []

    def fake_run(argv: list[str], **kwargs: object) -> None:
        observed_argv.extend(argv)
        temporary = Path(argv[-1])
        assert temporary.read_text(encoding="utf-8") == (
            "simulator:sim-secret\ndisplay-001:device-secret\n"
        )
        temporary.write_text("simulator:$hashed\ndisplay-001:$hashed\n", encoding="utf-8")

    monkeypatch.setattr(configure_local.subprocess, "run", fake_run)

    configure_local.write_password_file(
        destination,
        [("simulator", "sim-secret"), ("display-001", "device-secret")],
    )

    assert observed_argv[:2] == ["mosquitto_passwd", "-U"]
    assert "sim-secret" not in observed_argv
    assert "device-secret" not in observed_argv
    assert destination.read_text(encoding="utf-8").startswith("simulator:$hashed")
    assert stat.S_IMODE(destination.stat().st_mode) == 0o600
    assert list(tmp_path.glob(".passwords.*")) == []


def test_password_file_failure_cleans_plaintext_and_preserves_existing_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    destination = tmp_path / "passwords"
    destination.write_text("existing-hashes\n", encoding="utf-8")

    def fail(argv: list[str], **kwargs: object) -> None:
        raise subprocess.CalledProcessError(1, argv)

    monkeypatch.setattr(configure_local.subprocess, "run", fail)

    with pytest.raises(subprocess.CalledProcessError):
        configure_local.write_password_file(destination, [("user", "plaintext")])

    assert destination.read_text(encoding="utf-8") == "existing-hashes\n"
    assert list(tmp_path.glob(".passwords.*")) == []


def test_password_file_with_mosquitto_uses_hashed_output(tmp_path: Path) -> None:
    if shutil.which("mosquitto_passwd") is None:
        pytest.skip("mosquitto_passwd is required")
    destination = tmp_path / "passwords"

    configure_local.write_password_file(
        destination,
        [("simulator", "sim-secret"), ("display-001", "device-secret")],
    )

    content = destination.read_text(encoding="utf-8")
    assert "sim-secret" not in content
    assert "device-secret" not in content
    assert "simulator:$7$" in content
    assert "display-001:$7$" in content
