from pathlib import Path

import pytest

from simulator.publish_fixture import read_env_file


def test_read_env_file_accepts_only_mqtt_credentials(tmp_path: Path) -> None:
    env_file = tmp_path / "simulator.env"
    env_file.write_text(
        "# ignored local credentials\n"
        "INFOSCOPE_MQTT_USERNAME=simulator\n"
        "INFOSCOPE_MQTT_PASSWORD=private-value\n",
        encoding="utf-8",
    )

    assert read_env_file(env_file) == {
        "INFOSCOPE_MQTT_USERNAME": "simulator",
        "INFOSCOPE_MQTT_PASSWORD": "private-value",
    }


def test_read_env_file_rejects_unexpected_keys(tmp_path: Path) -> None:
    env_file = tmp_path / "simulator.env"
    env_file.write_text("UNEXPECTED=value\n", encoding="utf-8")

    with pytest.raises(SystemExit, match="unsupported env file key"):
        read_env_file(env_file)
