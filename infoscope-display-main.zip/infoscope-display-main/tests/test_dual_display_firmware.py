from pathlib import Path

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
FIRMWARE = (
    REPOSITORY_ROOT / "firmware" / "infoscope_display" / "infoscope_display.ino"
)


def test_frozen_dual_i2c_pin_mapping_and_constructor_order() -> None:
    source = FIRMWARE.read_text(encoding="utf-8")
    assert "constexpr uint8_t SPRITE_SDA = 21;" in source
    assert "constexpr uint8_t SPRITE_SCL = 22;" in source
    assert "constexpr uint8_t EVENT_SDA = 25;" in source
    assert "constexpr uint8_t EVENT_SCL = 26;" in source
    assert "Wire.begin(SPRITE_SDA, SPRITE_SCL);" in source
    assert "U8G2_SSD1306_128X64_NONAME_F_HW_I2C spriteDisplay" in source
    assert "U8G2_SSD1306_128X64_NONAME_F_SW_I2C eventDisplay" in source
    assert "/* clock=*/EVENT_SCL, /* data=*/EVENT_SDA" in source
    assert "/* clock=*/EVENT_SDA, /* data=*/EVENT_SCL" not in source


def test_each_display_owns_its_renderer_and_buffer() -> None:
    source = FIRMWARE.read_text(encoding="utf-8")
    assert "eventDisplay.drawUTF8" in source
    assert "eventDisplay.sendBuffer();" in source
    assert "spriteDisplay.drawBox" in source
    assert "spriteDisplay.sendBuffer();" in source
    assert "serviceAnimation(now);\n  serviceSprite(now);" in source
