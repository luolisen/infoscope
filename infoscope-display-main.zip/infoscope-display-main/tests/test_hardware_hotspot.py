from pathlib import Path

import pytest
from broker_dev_loader import load_broker_module

hotspot = load_broker_module("hardware_hotspot")


def test_read_string_constant_supports_define_and_constexpr(tmp_path: Path) -> None:
    define = tmp_path / "define.h"
    define.write_text('#define WIFI_PASSWORD "define-value"\n', encoding="utf-8")
    constexpr = tmp_path / "constexpr.h"
    constexpr.write_text(
        'constexpr char WIFI_PASSWORD[] = "constexpr-value";\n', encoding="utf-8"
    )

    assert hotspot.read_string_constant(define, "WIFI_PASSWORD") == "define-value"
    assert hotspot.read_string_constant(constexpr, "WIFI_PASSWORD") == "constexpr-value"


def test_start_rejects_primary_interface(tmp_path: Path) -> None:
    source = tmp_path / "wifi.h"
    source.write_text('#define WIFI_PASSWORD "private"\n', encoding="utf-8")

    with pytest.raises(SystemExit, match="must differ"):
        hotspot.start("wlan0", "wlan0", "ISD-LAB", source)
