from __future__ import annotations

import shutil
import socket
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path

import paho.mqtt.client as mqtt
import pytest

from simulator.contract import event_topic, load_and_encode

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
BROKER_CONFIG = REPOSITORY_ROOT / "broker-dev" / "config" / "mosquitto.conf"
COMPOSE_FILE = REPOSITORY_ROOT / "broker-dev" / "compose.yaml"


def test_committed_broker_config_freezes_security_and_persistence() -> None:
    config = BROKER_CONFIG.read_text(encoding="utf-8")
    compose = COMPOSE_FILE.read_text(encoding="utf-8")

    assert "allow_anonymous false" in config
    assert "password_file /mosquitto/config/secrets/passwords" in config
    assert "acl_file /mosquitto/config/secrets/acl" in config
    assert "persistence true" in config
    assert "persistence_location /mosquitto/data/" in config
    assert "persistence_file mosquitto.db" in config
    assert "eclipse-mosquitto:2.0.22" in compose


def free_port() -> int:
    with socket.socket() as server:
        server.bind(("127.0.0.1", 0))
        return int(server.getsockname()[1])


def wait_for_port(port: int, process: subprocess.Popen[bytes]) -> None:
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if process.poll() is not None:
            output = process.stdout.read().decode(errors="replace") if process.stdout else ""
            raise AssertionError(f"Mosquitto exited during startup: {output}")
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return
        except OSError:
            time.sleep(0.05)
    raise AssertionError("Mosquitto did not start")


@dataclass
class Broker:
    executable: Path
    config: Path
    port: int
    process: subprocess.Popen[bytes] | None = None

    def start(self) -> None:
        self.process = subprocess.Popen(
            [str(self.executable), "-c", str(self.config)],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        wait_for_port(self.port, self.process)

    def stop(self) -> None:
        if self.process is None:
            return
        self.process.terminate()
        self.process.wait(timeout=5)
        self.process = None


@pytest.fixture
def authenticated_broker(tmp_path: Path) -> Broker:
    if not shutil.which("mosquitto") or not shutil.which("mosquitto_passwd"):
        pytest.skip("Mosquitto 2.0.22 tools are required")

    secrets = tmp_path / "secrets"
    data = tmp_path / "data"
    secrets.mkdir()
    data.mkdir()
    executable = tmp_path / "mosquitto-test"
    shutil.copy2(shutil.which("mosquitto"), executable)
    executable.chmod(0o700)
    passwords = secrets / "passwords"
    subprocess.run(
        ["mosquitto_passwd", "-b", "-c", str(passwords), "simulator", "sim-pass"],
        check=True,
    )
    subprocess.run(
        ["mosquitto_passwd", "-b", str(passwords), "display-001", "device-pass"],
        check=True,
    )
    subprocess.run(
        ["mosquitto_passwd", "-b", str(passwords), "display-002", "other-pass"],
        check=True,
    )
    subprocess.run(
        ["mosquitto_passwd", "-b", str(passwords), "other-simulator", "other-sim-pass"],
        check=True,
    )
    passwords.chmod(0o600)
    acl = secrets / "acl"
    acl.write_text(
        "\n".join(
            [
                "user simulator",
                "topic write infoscope/v1/devices/display-001/events",
                "",
                "user display-001",
                "topic read infoscope/v1/devices/display-001/events",
                "",
                "user display-002",
                "topic read infoscope/v1/devices/display-002/events",
                "",
                "user other-simulator",
                "topic write infoscope/v1/devices/display-002/events",
                "",
            ]
        ),
        encoding="utf-8",
    )
    acl.chmod(0o600)
    port = free_port()
    config = tmp_path / "mosquitto.conf"
    config.write_text(
        "\n".join(
            [
                f"listener {port} 127.0.0.1",
                "allow_anonymous false",
                f"password_file {passwords}",
                f"acl_file {acl}",
                "persistence true",
                f"persistence_location {data}/",
                "persistence_file mosquitto.db",
                "",
            ]
        ),
        encoding="utf-8",
    )
    broker = Broker(executable=executable, config=config, port=port)
    broker.start()
    try:
        yield broker
    finally:
        broker.stop()


def connect_client(
    port: int,
    username: str | None = None,
    password: str | None = None,
) -> tuple[mqtt.Client, mqtt.ReasonCode]:
    connected = threading.Event()
    result: list[mqtt.ReasonCode] = []

    def on_connect(
        client: mqtt.Client,
        userdata: object,
        flags: mqtt.ConnectFlags,
        reason_code: mqtt.ReasonCode,
        properties: mqtt.Properties | None,
    ) -> None:
        result.append(reason_code)
        connected.set()

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, protocol=mqtt.MQTTv5)
    client.on_connect = on_connect
    if username is not None:
        client.username_pw_set(username, password)
    client.connect("127.0.0.1", port, keepalive=10)
    client.loop_start()
    assert connected.wait(3), "broker did not return CONNACK"
    return client, result[0]


def close_client(client: mqtt.Client) -> None:
    client.disconnect()
    client.loop_stop()


def test_broker_rejects_anonymous_connection(authenticated_broker: Broker) -> None:
    client, reason = connect_client(authenticated_broker.port)
    try:
        assert reason.is_failure
    finally:
        close_client(client)


def test_device_acl_blocks_delivery_from_another_device_topic(
    authenticated_broker: Broker,
) -> None:
    client, reason = connect_client(authenticated_broker.port, "display-001", "device-pass")
    assert not reason.is_failure
    subscribed = threading.Event()
    received = threading.Event()

    def on_subscribe(
        mqtt_client: mqtt.Client,
        userdata: object,
        mid: int,
        reason_codes: list[mqtt.ReasonCode],
        properties: mqtt.Properties | None,
    ) -> None:
        subscribed.set()

    def on_message(
        mqtt_client: mqtt.Client,
        userdata: object,
        message: mqtt.MQTTMessage,
    ) -> None:
        received.set()

    client.on_subscribe = on_subscribe
    client.on_message = on_message
    client.subscribe(event_topic("display-002"), qos=1)
    try:
        assert subscribed.wait(3)
        publisher, publish_reason = connect_client(
            authenticated_broker.port, "other-simulator", "other-sim-pass"
        )
        assert not publish_reason.is_failure
        published = publisher.publish(
            event_topic("display-002"), load_and_encode(), qos=1, retain=False
        )
        published.wait_for_publish(timeout=3)
        close_client(publisher)
        assert not received.wait(0.5)
    finally:
        close_client(client)


def test_retained_snapshot_survives_normal_restart(authenticated_broker: Broker) -> None:
    payload = load_and_encode()
    publisher, reason = connect_client(authenticated_broker.port, "simulator", "sim-pass")
    assert not reason.is_failure
    published = publisher.publish(event_topic("display-001"), payload, qos=1, retain=True)
    published.wait_for_publish(timeout=3)
    close_client(publisher)

    authenticated_broker.stop()
    authenticated_broker.start()

    received = threading.Event()
    messages: list[mqtt.MQTTMessage] = []
    subscriber, reason = connect_client(
        authenticated_broker.port, "display-001", "device-pass"
    )
    assert not reason.is_failure

    def on_message(
        client: mqtt.Client,
        userdata: object,
        message: mqtt.MQTTMessage,
    ) -> None:
        messages.append(message)
        received.set()

    subscriber.on_message = on_message
    subscriber.subscribe(event_topic("display-001"), qos=1)
    try:
        assert received.wait(3)
        assert messages[0].payload == payload
        assert messages[0].retain
    finally:
        close_client(subscriber)
