# infoscope-display
Standalone ESP32 MQTT OLED display terminal
