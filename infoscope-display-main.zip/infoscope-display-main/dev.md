# Infoscope Display — execution baseline

Status: **A1 merged; A2 integration baseline proposed**. A2 code starts only after this four-document baseline is approved.

## Local progress ledger (2026-08-18)

| Phase | Local evidence | State |
| --- | --- | --- |
| 0.5 | Contract PR merged; immutable `display-events-v1` points to `82aa4173` | Complete |
| A1.1 | `56276dc`; canonical-fixture simulator and host tests | Implemented locally |
| A1.2 | `5297318`; authenticated Mosquitto, ACL, retained restart tests | Implemented locally |
| A1.3–A1.5 | `2706211` plus follow-up observability changes; dual buses, exact sprite frames/timing, Event migration | Implemented locally; 55 host tests and Arduino compile pass |
| A1.6 | ESP32 upload; authenticated MQTT, retained, boundary/error, broker and AP recovery; sprite state logs; human dual-OLED visual confirmation | Complete; merged as PR #7; hardware tag remains uncreated |

The branch and commits above are rollback checkpoints, not approval or merge records. Nothing may be tagged or self-merged from this ledger. The earlier single-adapter hotspot experiment was fully rolled back; the retained helper requires a distinct secondary adapter and verifies that the primary development connection is unchanged.

## Git and review rules

- `main` is integration-only: no direct push.
- One phase uses one short-lived `docs/...` or `feat/...` branch and one PR.
- Every PR requires Alan review; the author must not approve or merge their own PR.
- Use Squash Merge after approval and delete the merged branch.
- Until GitHub plan supports enforced protection, these are mandatory manual rules. Enable required non-author approval, up-to-date branch, and CI checks when policy permits.
- Tags are never used for active development.
- Allowed tags:
  - `display-events-v1`: created only after the reviewed Phase 0.5 Contract PR merges.
  - `a1-hardware-verified`: created only after physical A1 acceptance.
- Published Contract and hardware-acceptance tags must never be moved or reused.

## Phase 0 — document freeze

| Field | Requirement |
| --- | --- |
| Input | A1 requirements |
| Output | `plan.md`, `tech.md`, `style.md`, `dev.md` only |
| Tests | Markdown review / none |
| Done | Alan replies **Baseline Approved** and merges docs PR |
| Owner | Lingjiu writes; Alan reviews |
| Allowed | four root Markdown files |
| Prohibited | all code, config, fixture, broker, and application changes |

## Phase 0.5 — ISD canonical Contract v1

| Field | Requirement |
| --- | --- |
| Owner | Lingjiu implements in ISD; Alan reviews |
| Input | merged A1 documents |
| Output | `contracts/mqtt/` Schema, canonical fixture, Contract tests, architecture note, immutable `display-events-v1` tag |
| Tests | schema validates fixture / none |
| Done | ISD Contract PR reviewed and merged; tag records immutable Contract v1 for A1 |
| Allowed | `contracts/mqtt/`, `tests/`, and test dependency lock files in ISD |
| Prohibited | `infoscope` changes, device firmware, database/API/Pipeline changes, live publisher |

## Phase A1.1 — simulator and host tests

| Field | Requirement |
| --- | --- |
| Input | merged, tagged ISD Contract v1 fixture |
| Output | `simulator/`, `tests/`, Python lock file |
| Tests | canonical fixture regression, exact 4096-byte payload, 0/12 Events, ordering, duplicate revision / none |
| Done | simulator emits the ISD canonical Contract v1 fixture; lock-backed tests pass |
| Owner | Lingjiu |
| Prohibited | temporary Contract, firmware, backend changes |

## Phase A1.2 — authenticated broker

| Field | Requirement |
| --- | --- |
| Input | device ID, canonical topic, and exact Mosquitto `2.0.22` image tag |
| Output | `broker-dev/`, `tests/` |
| Tests | anonymous and unauthorized topic denied; clean-data normal-stop retained recovery / LAN-only reachability |
| Done | separate publisher/device credentials and ACL pass tests; ignored `broker-dev/data/` persistence is reproducible |
| Owner | Lingjiu |
| Prohibited | committed secrets, anonymous broker, public exposure, TLS/cloud work |

## Phase A1.3 — device state machine

| Field | Requirement |
| --- | --- |
| Input | local configuration template, authenticated broker, hardware sprite bus SDA 21 / SCL 22, and software Event bus SDA 25 / SCL 26; U8g2 Event constructor uses `clock=26, data=25` |
| Output | `firmware/`, `tests/` |
| Tests | state/backoff helpers; contradiction check for sprite SDA 21 / SCL 22, Event SDA 25 / SCL 26, and U8g2 `clock=26, data=25`; Arduino compile / Wi-Fi and MQTT recovery |
| Done | non-blocking reconnect, secret-safe logs, and no reversed software-I²C pin mapping |
| Owner | Lingjiu |
| Prohibited | MQTT status topic, remote status mapping, API, OTA, provisioning |

The A1.3 baseline consistency check must fail if any document or firmware constant reverses Event SDA/SCL or passes `clock=25, data=26`. The only valid mapping is Event SDA 25, Event SCL 26, therefore U8g2 software-I²C `clock=26, data=25`.

## Phase A1.4 — dual-display static renderers

| Field | Requirement |
| --- | --- |
| Input | frozen Event layout and exact sprite matrices |
| Output | `firmware/`, `tests/` |
| Tests | pixel truncation/glyph replacement, matrix dimensions / readable Event rows and sprite acknowledgement |
| Done | both fixed-address OLEDs work on separate buses without cross-buffer clearing |
| Owner | Lingjiu |
| Prohibited | third display, unlisted sprite art, remote status topic |

## Phase A1.5 — snapshots and transitions

| Field | Requirement |
| --- | --- |
| Input | completed A1.1–A1.4 |
| Output | `firmware/`, `simulator/`, `tests/` |
| Tests | malformed/oversized rejection, retained fixture, dedup, sprite timing / transition and broker restart |
| Done | Event behavior remains correct while the local sprite stays responsive |
| Owner | Lingjiu |
| Prohibited | third display, status topic, real publisher |

## Phase A1.6 — physical acceptance

| Field | Requirement |
| --- | --- |
| Input | completed A1.1–A1.5 and one physical ESP32 + two SSD1306 modules |
| Output | approved hardware acceptance record |
| Tests | all prior checks / all `plan.md` DoD cases |
| Done | Alan reviews acceptance; tag `a1-hardware-verified` may be created |
| Owner | Lingjiu validates device; Alan reviews record |
| Prohibited | A2, remote status topic, Contract mutation, backend integration |

## Phase A2.0 — integration baseline freeze

| Field | Requirement |
| --- | --- |
| Input | merged A1, immutable `display-events-v1`, and the two-repository ownership boundary |
| Output | this A2 revision of `plan.md`, `tech.md`, `style.md`, and `dev.md` only |
| Tests | Markdown review / Contract tag and scope consistency check |
| Done | Alan approves the A2 baseline before either repository writes A2 code |
| Owner | Lingjiu drafts ISD device boundary; Alan approves publisher boundary |
| Allowed | four root Markdown files in ISD |
| Prohibited | Contract mutation, backend code, firmware behavior change, status topic |

The A2.0 handoff deliverable is created at the boundary between A2.0 and A2.1: `docs/a2-publisher-handoff.md`. It is written once the four-document baseline is accepted and before Alan creates the publisher branch. It must specify API input/output, `infoscope` branch/PR and squash-merge order, the immutable ISD Contract tag/commit, ignored configuration names, ownership of upstream→broker→ESP32→OLED tests, rollback points, and the evidence required for transfer. Do not write it earlier from assumptions or later after the API has diverged.

## Phase A2.1 — Infoscope publisher adapter

| Field | Requirement |
| --- | --- |
| Input | approved A2 baseline and `display-events-v1` tag/commit |
| Output | `infoscope`-only DisplaySnapshotService, publisher adapter, binding/ACL configuration, and tests |
| Tests | device binding, visible Event ordering, Contract validation, retained QoS 1 publication, cross-device denial |
| Done | real publisher emits only valid tagged Contract v1 for the bound device |
| Owner | Alan / `infoscope` |
| Allowed | `infoscope` A2 integration directories only |
| Prohibited | changes by Lingjiu to Infoscope application logic; duplicate Schema; Contract v1 mutation |

Handoff order: Alan creates `feat/integration-mqtt-display` from the latest `infoscope/main`, implements and tests the Publisher API, and opens its PR; after that PR is approved/merged, Lingjiu creates the ISD joint-test branch from the latest ISD `main` and records the end-to-end evidence. Neither side cherry-picks the other repository's business logic.

## Phase A2.2 — joint device acceptance

| Field | Requirement |
| --- | --- |
| Input | completed A2.1, provisioned private broker endpoint, device-only credential, and bound test user |
| Output | ISD joint-acceptance evidence; only device configuration/test changes if a defect is found |
| Tests | real snapshot equivalence, unauthorized device denial, Worker/broker/Wi-Fi/ESP32 restart, duplicate revision behavior |
| Done | bound user's newest three titles display correctly and recover without exposing another user's data |
| Owner | Lingjiu validates hardware; Alan validates publisher and privacy |
| Allowed | ISD firmware/configuration/tests needed to consume the existing Contract |
| Prohibited | user identifiers or publisher credentials in firmware/logs; remote sprite/status mapping; Contract mutation |
