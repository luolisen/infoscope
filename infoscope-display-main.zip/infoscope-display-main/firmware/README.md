# ESP32 dual-display firmware

Frozen target: ESP32 DevKit and two SSD1306 128×64 OLEDs, both at address `0x3C` but on electrically separate buses:

- hardware I²C sprite OLED: SDA GPIO 21, SCL GPIO 22;
- software I²C Event OLED: SDA GPIO 25, SCL GPIO 26; U8g2 receives `clock=26, data=25`.

Pinned dependencies:

- ESP32 Arduino core `2.0.17`
- `256dpi/MQTT` `2.5.3`
- `ArduinoJson` `6.21.5`
- `U8g2` `2.36.19`

Install the exact core and libraries with Arduino CLI if the shared toolchain is not already prepared:

```bash
arduino-cli core install esp32:esp32@2.0.17
arduino-cli lib install MQTT@2.5.3 ArduinoJson@6.21.5 U8g2@2.36.19
```

Copy `infoscope_display/include/local_config.example.h` to the ignored `local_config.h` and set local Wi-Fi, authenticated MQTT, and device values. Never commit or print those secrets.

Build and upload:

```bash
ARDUINO_CLI=/path/to/arduino-cli firmware/build.sh
ARDUINO_CLI=/path/to/arduino-cli firmware/upload.sh /dev/ttyUSB0
```

The firmware uses a 4608-byte MQTT receive buffer, validates Display Contract v1 into a 6144-byte JSON document, displays only `title`, ignores opaque `id`/`state`, preserves the newest valid page on errors or disconnects, deduplicates revisions, and keeps only the latest validated snapshot during a non-blocking upward transition. The independent hardware-I²C renderer shows the frozen local boot/connecting/online/offline/protocol-error sprite without consuming a status topic.
