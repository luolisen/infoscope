#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SKETCH_DIR="$SCRIPT_DIR/infoscope_display"
ARDUINO_CLI=${ARDUINO_CLI:-arduino-cli}
FQBN=esp32:esp32:esp32
BUILD_DIR="$SKETCH_DIR/build"

test -f "$SKETCH_DIR/include/local_config.h" || {
  echo "copy include/local_config.example.h to include/local_config.h before building" >&2
  exit 1
}

"$ARDUINO_CLI" compile --fqbn "$FQBN" --output-dir "$BUILD_DIR" "$SKETCH_DIR"
