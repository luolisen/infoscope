#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SKETCH_DIR="$SCRIPT_DIR/infoscope_display"
ARDUINO_CLI=${ARDUINO_CLI:-arduino-cli}
FQBN=esp32:esp32:esp32
PORT=${1:-/dev/ttyUSB0}
BUILD_DIR="$SKETCH_DIR/build"

test -c "$PORT" || {
  echo "ESP32 serial device not found: $PORT" >&2
  exit 1
}

"$SCRIPT_DIR/build.sh"
"$ARDUINO_CLI" upload --fqbn "$FQBN" --port "$PORT" --input-dir "$BUILD_DIR" "$SKETCH_DIR"
