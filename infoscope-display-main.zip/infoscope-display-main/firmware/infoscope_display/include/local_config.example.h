#pragma once

// Copy to local_config.h and edit locally. local_config.h is ignored by Git.
constexpr char WIFI_SSID[] = "your-wifi";
constexpr char WIFI_PASSWORD[] = "your-wifi-password";
constexpr char MQTT_HOST[] = "192.0.2.10";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USERNAME[] = "display-001";
constexpr char MQTT_PASSWORD[] = "your-device-password";
constexpr char DEVICE_ID[] = "display-001";
