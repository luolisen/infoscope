#include <Arduino.h>
#include <ArduinoJson.h>
#include <MQTT.h>
#include <U8g2lib.h>
#include <WiFi.h>
#include <Wire.h>

#include "core_logic.h"

#if __has_include("include/local_config.h")
#include "include/local_config.h"
#else
#error "Copy include/local_config.example.h to include/local_config.h before building"
#endif

namespace {

constexpr uint8_t SPRITE_SDA = 21;
constexpr uint8_t SPRITE_SCL = 22;
constexpr uint8_t EVENT_SDA = 25;
constexpr uint8_t EVENT_SCL = 26;
constexpr uint8_t OLED_ADDRESS = 0x3C;
constexpr size_t MAX_PAYLOAD_BYTES = 4096;
constexpr size_t MQTT_RECEIVE_BUFFER = 4608;
constexpr size_t JSON_CAPACITY = 6144;
constexpr uint8_t MAX_EVENTS = 12;
constexpr uint8_t PAGE_SIZE = 3;
constexpr uint16_t TITLE_MAX_CODEPOINTS = 120;
constexpr uint32_t WIFI_ATTEMPT_TIMEOUT_MS = 10000;
constexpr uint32_t BOOT_SCREEN_MS = 700;
constexpr uint32_t ERROR_FILLED_MS = 3000;
constexpr uint32_t ANIMATION_FRAME_MS = 20;
constexpr int8_t ANIMATION_STEP_PX = 8;
constexpr int8_t SCREEN_HEIGHT = 64;
constexpr int8_t TITLE_WIDTH_PX = 120;
constexpr int8_t BASELINES[PAGE_SIZE] = {17, 38, 59};

enum class ParseResult : uint8_t { VALID, INVALID };

struct Snapshot {
  String revision;
  uint8_t count = 0;
  bool glyphReplaced = false;
  String titles[MAX_EVENTS];
};

U8G2_SSD1306_128X64_NONAME_F_HW_I2C spriteDisplay(U8G2_R0, U8X8_PIN_NONE);
U8G2_SSD1306_128X64_NONAME_F_SW_I2C eventDisplay(
    U8G2_R0, /* clock=*/EVENT_SCL, /* data=*/EVENT_SDA, U8X8_PIN_NONE);
WiFiClient network;
MQTTClient mqtt(MQTT_RECEIVE_BUFFER);
StaticJsonDocument<JSON_CAPACITY> jsonDocument;

String eventTopic;
String inboundPayload;
bool inboundPending = false;
bool inboundOversized = false;

Snapshot currentSnapshot;
Snapshot animationTarget;
Snapshot queuedSnapshot;
bool hasSnapshot = false;
bool animationActive = false;
bool queuedSnapshotValid = false;
int8_t animationOffset = 0;
uint32_t nextAnimationFrameAt = 0;

bool protocolError = false;
bool protocolErrorFilled = false;
uint32_t protocolErrorFilledUntil = 0;
bool displayDirty = true;
uint32_t bootScreenUntil = 0;

isd::SpriteState spriteState = isd::SpriteState::BOOT;
isd::SpriteFrame spriteFrame = isd::SpriteFrame::OPEN;
uint32_t spriteStateStartedAt = 0;
bool spriteRendered = false;
bool everOnline = false;

bool wifiAttemptActive = false;
uint8_t wifiFailures = 0;
uint8_t mqttFailures = 0;
uint32_t wifiAttemptStartedAt = 0;
uint32_t nextWifiAttemptAt = 0;
uint32_t nextMqttAttemptAt = 0;
bool previousWifiConnected = false;
bool previousMqttConnected = false;

bool decodeCodePoint(const String &text, size_t &offset, uint32_t &codePoint, size_t &bytes) {
  if (offset >= text.length()) return false;
  const uint8_t first = static_cast<uint8_t>(text[offset]);
  if (first < 0x80) {
    codePoint = first;
    bytes = 1;
  } else if ((first & 0xE0) == 0xC0) {
    codePoint = first & 0x1F;
    bytes = 2;
  } else if ((first & 0xF0) == 0xE0) {
    codePoint = first & 0x0F;
    bytes = 3;
  } else if ((first & 0xF8) == 0xF0) {
    codePoint = first & 0x07;
    bytes = 4;
  } else {
    return false;
  }
  if (offset + bytes > text.length()) return false;
  for (size_t index = 1; index < bytes; ++index) {
    uint8_t continuation = static_cast<uint8_t>(text[offset + index]);
    if ((continuation & 0xC0) != 0x80) return false;
    codePoint = (codePoint << 6) | (continuation & 0x3F);
  }
  if ((bytes == 2 && codePoint < 0x80) || (bytes == 3 && codePoint < 0x800) ||
      (bytes == 4 && codePoint < 0x10000) || codePoint > 0x10FFFF ||
      (codePoint >= 0xD800 && codePoint <= 0xDFFF)) {
    return false;
  }
  return true;
}

bool validUtf8WithLimit(const String &text, size_t maximumCodePoints) {
  size_t offset = 0;
  size_t count = 0;
  while (offset < text.length()) {
    uint32_t codePoint = 0;
    size_t bytes = 0;
    if (!decodeCodePoint(text, offset, codePoint, bytes)) return false;
    offset += bytes;
    if (++count > maximumCodePoints) return false;
  }
  return count > 0;
}

bool isUnicodeWhitespace(uint32_t codePoint) {
  return (codePoint >= 0x0009 && codePoint <= 0x000D) || codePoint == 0x0020 ||
         codePoint == 0x0085 || codePoint == 0x00A0 || codePoint == 0x1680 ||
         (codePoint >= 0x2000 && codePoint <= 0x200A) || codePoint == 0x2028 ||
         codePoint == 0x2029 || codePoint == 0x202F || codePoint == 0x205F ||
         codePoint == 0x3000;
}

bool normalizeTitle(const String &source, String &normalized) {
  normalized = "";
  normalized.reserve(source.length());
  size_t offset = 0;
  bool pendingSpace = false;
  while (offset < source.length()) {
    uint32_t codePoint = 0;
    size_t bytes = 0;
    size_t start = offset;
    if (!decodeCodePoint(source, offset, codePoint, bytes)) return false;
    offset += bytes;
    if (isUnicodeWhitespace(codePoint)) {
      if (normalized.length() > 0) pendingSpace = true;
      continue;
    }
    if (pendingSpace) {
      normalized += ' ';
      pendingSpace = false;
    }
    normalized += source.substring(start, offset);
  }
  return validUtf8WithLimit(normalized, TITLE_MAX_CODEPOINTS);
}

bool asciiDigit(char value) {
  return value >= '0' && value <= '9';
}

uint8_t twoDigits(const String &value, size_t offset) {
  return static_cast<uint8_t>((value[offset] - '0') * 10 + value[offset + 1] - '0');
}

uint16_t fourDigits(const String &value, size_t offset) {
  return static_cast<uint16_t>((value[offset] - '0') * 1000 +
                               (value[offset + 1] - '0') * 100 +
                               (value[offset + 2] - '0') * 10 + value[offset + 3] - '0');
}

bool validDateTimeShape(const String &value) {
  if (value.length() < 20 || value.length() > 40) return false;
  constexpr uint8_t digitPositions[] = {0, 1, 2, 3, 5, 6, 8, 9, 11, 12, 14, 15, 17, 18};
  for (uint8_t position : digitPositions) {
    if (!asciiDigit(value[position])) return false;
  }
  if (value[4] != '-' || value[7] != '-' || (value[10] != 'T' && value[10] != 't') ||
      value[13] != ':' || value[16] != ':' || twoDigits(value, 5) < 1 ||
      twoDigits(value, 5) > 12 || twoDigits(value, 8) < 1 ||
      !isd::validCalendarDate(fourDigits(value, 0), twoDigits(value, 5),
                              twoDigits(value, 8)) ||
      twoDigits(value, 11) > 23 || twoDigits(value, 14) > 59 ||
      twoDigits(value, 17) > 60) {
    return false;
  }
  size_t offset = 19;
  if (value[offset] == '.') {
    if (++offset >= value.length() || !asciiDigit(value[offset])) return false;
    while (offset < value.length() && asciiDigit(value[offset])) ++offset;
  }
  if (offset + 1 == value.length() && (value[offset] == 'Z' || value[offset] == 'z')) {
    return true;
  }
  if (offset + 6 != value.length() || (value[offset] != '+' && value[offset] != '-') ||
      !asciiDigit(value[offset + 1]) || !asciiDigit(value[offset + 2]) ||
      value[offset + 3] != ':' || !asciiDigit(value[offset + 4]) ||
      !asciiDigit(value[offset + 5])) {
    return false;
  }
  return twoDigits(value, offset + 1) <= 23 && twoDigits(value, offset + 4) <= 59;
}

String replaceUnsupportedGlyphs(const String &source, bool &replaced) {
  String result;
  result.reserve(source.length());
  size_t offset = 0;
  while (offset < source.length()) {
    uint32_t codePoint = 0;
    size_t bytes = 0;
    size_t start = offset;
    if (!decodeCodePoint(source, offset, codePoint, bytes)) break;
    offset += bytes;
    if (codePoint <= UINT16_MAX &&
        u8g2_IsGlyph(eventDisplay.getU8g2(), static_cast<uint16_t>(codePoint))) {
      result += source.substring(start, offset);
    } else {
      result += '?';
      replaced = true;
    }
  }
  return result;
}

bool onlyTopLevelKeys(JsonObjectConst object) {
  if (object.size() != 4) return false;
  for (JsonPairConst pair : object) {
    const char *key = pair.key().c_str();
    if (strcmp(key, "schema") && strcmp(key, "revision") && strcmp(key, "generated_at") &&
        strcmp(key, "events")) {
      return false;
    }
  }
  return true;
}

bool onlyEventKeys(JsonObjectConst object) {
  if (object.size() != 4) return false;
  for (JsonPairConst pair : object) {
    const char *key = pair.key().c_str();
    if (strcmp(key, "id") && strcmp(key, "title") && strcmp(key, "state") &&
        strcmp(key, "display_time")) {
      return false;
    }
  }
  return true;
}

void rejectPayload(const __FlashStringHelper *reason) {
  protocolError = true;
  protocolErrorFilled = true;
  protocolErrorFilledUntil = millis() + ERROR_FILLED_MS;
  displayDirty = true;
  Serial.print(F("contract reject: "));
  Serial.println(reason);
}

ParseResult parseSnapshot(const String &payload, Snapshot &output) {
  jsonDocument.clear();
  DeserializationError error = deserializeJson(jsonDocument, payload.c_str(), payload.length());
  if (error) return ParseResult::INVALID;
  JsonObjectConst root = jsonDocument.as<JsonObjectConst>();
  if (root.isNull() || !onlyTopLevelKeys(root)) return ParseResult::INVALID;
  if (!root["schema"].is<const char *>() ||
      strcmp(root["schema"].as<const char *>(), "infoscope.display.events.v1")) {
    return ParseResult::INVALID;
  }
  if (!root["revision"].is<const char *>() || !root["generated_at"].is<const char *>() ||
      !root["events"].is<JsonArrayConst>()) {
    return ParseResult::INVALID;
  }
  String revision = root["revision"].as<const char *>();
  String generatedAt = root["generated_at"].as<const char *>();
  if (!validUtf8WithLimit(revision, 128) || !validDateTimeShape(generatedAt)) {
    return ParseResult::INVALID;
  }

  JsonArrayConst events = root["events"].as<JsonArrayConst>();
  if (events.size() > MAX_EVENTS) return ParseResult::INVALID;
  Snapshot candidate;
  candidate.revision = revision;
  for (JsonVariantConst value : events) {
    if (!value.is<JsonObjectConst>()) return ParseResult::INVALID;
    JsonObjectConst event = value.as<JsonObjectConst>();
    if (!onlyEventKeys(event) || !event["id"].is<const char *>() ||
        !event["title"].is<const char *>() || !event["state"].is<const char *>() ||
        !event["display_time"].is<const char *>()) {
      return ParseResult::INVALID;
    }
    String id = event["id"].as<const char *>();
    String sourceTitle = event["title"].as<const char *>();
    String state = event["state"].as<const char *>();
    String displayTime = event["display_time"].as<const char *>();
    String normalizedTitle;
    if (!validUtf8WithLimit(id, 128) || !validUtf8WithLimit(state, 64) ||
        !validDateTimeShape(displayTime) || !normalizeTitle(sourceTitle, normalizedTitle) ||
        normalizedTitle != sourceTitle) {
      return ParseResult::INVALID;
    }
    candidate.titles[candidate.count++] =
        replaceUnsupportedGlyphs(normalizedTitle, candidate.glyphReplaced);
  }
  output = candidate;
  return ParseResult::VALID;
}

String ellipsisText() {
  return eventDisplay.getUTF8Width("…") > 0 ? String("…") : String("...");
}

String truncateTitle(const String &source, int16_t maximumWidth) {
  if (eventDisplay.getUTF8Width(source.c_str()) <= maximumWidth) return source;
  String suffix = ellipsisText();
  int16_t suffixWidth = eventDisplay.getUTF8Width(suffix.c_str());
  String result;
  size_t offset = 0;
  while (offset < source.length()) {
    uint32_t codePoint = 0;
    size_t bytes = 0;
    size_t start = offset;
    if (!decodeCodePoint(source, offset, codePoint, bytes)) break;
    offset += bytes;
    String candidate = result + source.substring(start, offset);
    if (eventDisplay.getUTF8Width(candidate.c_str()) + suffixWidth > maximumWidth) break;
    result = candidate;
  }
  return result + suffix;
}

void pageLines(const Snapshot &snapshot, String lines[PAGE_SIZE]) {
  for (uint8_t index = 0; index < PAGE_SIZE; ++index) lines[index] = "";
  uint8_t start = snapshot.count > PAGE_SIZE ? snapshot.count - PAGE_SIZE : 0;
  for (uint8_t index = start; index < snapshot.count; ++index) {
    lines[index - start] = truncateTitle(snapshot.titles[index], TITLE_WIDTH_PX);
  }
}

void drawCentered(const char *text) {
  int16_t width = eventDisplay.getUTF8Width(text);
  eventDisplay.drawUTF8(max<int16_t>(0, (128 - width) / 2), 36, text);
}

void drawMarker(bool filled) {
  if (filled) {
    eventDisplay.drawBox(121, 1, 6, 6);
  } else {
    eventDisplay.drawFrame(121, 1, 6, 6);
  }
}

void drawSnapshotAt(const Snapshot &snapshot, int8_t shift) {
  String lines[PAGE_SIZE];
  pageLines(snapshot, lines);
  for (uint8_t index = 0; index < PAGE_SIZE; ++index) {
    int16_t y = BASELINES[index] + shift;
    if (lines[index].length() && y >= 0 && y <= SCREEN_HEIGHT) {
      eventDisplay.drawUTF8(0, y, lines[index].c_str());
    }
  }
}

void drawStatusMarker(uint32_t now) {
  bool offline = WiFi.status() != WL_CONNECTED || !mqtt.connected();
  if (protocolError) {
    drawMarker(protocolErrorFilled);
  } else if (offline) {
    drawMarker(false);
  }
}

void renderCurrent(uint32_t now) {
  if (animationActive) return;
  eventDisplay.clearBuffer();
  eventDisplay.setFont(u8g2_font_wqy12_t_gb2312);
  if (!isd::timeReached(now, bootScreenUntil)) {
    drawCentered("观澜启动中");
  } else if (hasSnapshot) {
    if (currentSnapshot.count == 0) {
      drawCentered("暂无 Event");
    } else {
      drawSnapshotAt(currentSnapshot, 0);
    }
    drawStatusMarker(now);
  } else if (protocolError) {
    drawCentered("消息格式错误");
  } else if (WiFi.status() != WL_CONNECTED) {
    drawCentered("Wi-Fi 连接中");
  } else if (!mqtt.connected()) {
    drawCentered("MQTT 连接中");
  } else {
    drawCentered("暂无 Event");
  }
  eventDisplay.sendBuffer();
  displayDirty = false;
}

void renderAnimationFrame(uint32_t now) {
  eventDisplay.clearBuffer();
  eventDisplay.setFont(u8g2_font_wqy12_t_gb2312);
  drawSnapshotAt(currentSnapshot, -animationOffset);
  drawSnapshotAt(animationTarget, SCREEN_HEIGHT - animationOffset);
  drawStatusMarker(now);
  eventDisplay.sendBuffer();
}

isd::SpriteState desiredSpriteState(uint32_t now) {
  if (!isd::timeReached(now, bootScreenUntil)) return isd::SpriteState::BOOT;
  if (protocolError) return isd::SpriteState::PROTOCOL_ERROR;
  if (WiFi.status() != WL_CONNECTED) {
    return everOnline ? isd::SpriteState::OFFLINE : isd::SpriteState::WIFI_CONNECTING;
  }
  if (!mqtt.connected()) {
    return everOnline ? isd::SpriteState::OFFLINE : isd::SpriteState::MQTT_CONNECTING;
  }
  return isd::SpriteState::ONLINE;
}

const char *spriteLabel(isd::SpriteState state) {
  switch (state) {
    case isd::SpriteState::BOOT:
      return "启动中";
    case isd::SpriteState::WIFI_CONNECTING:
      return "Wi-Fi 连接中";
    case isd::SpriteState::MQTT_CONNECTING:
      return "MQTT 连接中";
    case isd::SpriteState::ONLINE:
      return "在线";
    case isd::SpriteState::OFFLINE:
      return "离线";
    case isd::SpriteState::PROTOCOL_ERROR:
      return "消息错误";
  }
  return "";
}

const char *spriteStateName(isd::SpriteState state) {
  switch (state) {
    case isd::SpriteState::BOOT:
      return "boot";
    case isd::SpriteState::WIFI_CONNECTING:
      return "wifi_connecting";
    case isd::SpriteState::MQTT_CONNECTING:
      return "mqtt_connecting";
    case isd::SpriteState::ONLINE:
      return "online";
    case isd::SpriteState::OFFLINE:
      return "offline";
    case isd::SpriteState::PROTOCOL_ERROR:
      return "protocol_error";
  }
  return "unknown";
}

void renderSprite(isd::SpriteState state, isd::SpriteFrame frame) {
  constexpr uint8_t scale = 4;
  constexpr uint8_t originX = 46;
  constexpr uint8_t originY = 4;
  spriteDisplay.clearBuffer();
  const char (*pixels)[13] = isd::SPRITE_PIXELS[static_cast<uint8_t>(frame)];
  for (uint8_t row = 0; row < 12; ++row) {
    for (uint8_t column = 0; column < 12; ++column) {
      if (pixels[row][column] == '#') {
        spriteDisplay.drawBox(originX + column * scale, originY + row * scale, scale,
                              scale);
      }
    }
  }
  spriteDisplay.setFont(u8g2_font_wqy12_t_gb2312);
  const char *label = spriteLabel(state);
  int16_t width = spriteDisplay.getUTF8Width(label);
  spriteDisplay.drawUTF8(max<int16_t>(0, (128 - width) / 2), 61, label);
  spriteDisplay.sendBuffer();
}

void serviceSprite(uint32_t now) {
  isd::SpriteState nextState = desiredSpriteState(now);
  if (nextState != spriteState) {
    spriteState = nextState;
    spriteStateStartedAt = now;
    spriteRendered = false;
    Serial.printf("sprite state=%s\n", spriteStateName(spriteState));
  }
  isd::SpriteFrame nextFrame = isd::spriteFrameAt(spriteState, now - spriteStateStartedAt);
  if (!spriteRendered || nextFrame != spriteFrame) {
    spriteFrame = nextFrame;
    renderSprite(spriteState, spriteFrame);
    spriteRendered = true;
  }
}

void beginAnimation(const Snapshot &next, uint32_t now) {
  animationTarget = next;
  animationActive = true;
  animationOffset = 0;
  nextAnimationFrameAt = now;
  if (next.glyphReplaced) {
    Serial.printf("render warning: unsupported glyph revision=%s\n", next.revision.c_str());
  }
}

void acceptSnapshot(const Snapshot &snapshot, uint32_t now) {
  protocolError = false;
  protocolErrorFilled = false;
  if (!hasSnapshot) {
    currentSnapshot = snapshot;
    hasSnapshot = true;
    displayDirty = true;
    if (snapshot.glyphReplaced) {
      Serial.printf("render warning: unsupported glyph revision=%s\n",
                    snapshot.revision.c_str());
    }
    Serial.printf("snapshot accepted revision=%s events=%u first=true\n",
                  snapshot.revision.c_str(), snapshot.count);
    return;
  }
  beginAnimation(snapshot, now);
  Serial.printf("snapshot accepted revision=%s events=%u animate=true\n",
                snapshot.revision.c_str(), snapshot.count);
}

void serviceAnimation(uint32_t now) {
  if (!animationActive || !isd::timeReached(now, nextAnimationFrameAt)) return;
  renderAnimationFrame(now);
  if (animationOffset >= SCREEN_HEIGHT) {
    currentSnapshot = animationTarget;
    animationActive = false;
    displayDirty = true;
    if (queuedSnapshotValid) {
      Snapshot next = queuedSnapshot;
      queuedSnapshotValid = false;
      if (next.revision != currentSnapshot.revision) beginAnimation(next, now);
    }
    return;
  }
  animationOffset += ANIMATION_STEP_PX;
  nextAnimationFrameAt = now + ANIMATION_FRAME_MS;
}

void processInbound(uint32_t now) {
  if (inboundOversized) {
    inboundOversized = false;
    rejectPayload(F("payload exceeds 4096 bytes"));
  }
  if (!inboundPending) return;
  String payload = inboundPayload;
  inboundPending = false;
  Snapshot candidate;
  if (parseSnapshot(payload, candidate) != ParseResult::VALID) {
    rejectPayload(F("invalid display-events-v1 payload"));
    return;
  }
  if ((hasSnapshot && candidate.revision == currentSnapshot.revision) ||
      (animationActive && candidate.revision == animationTarget.revision) ||
      (queuedSnapshotValid && candidate.revision == queuedSnapshot.revision)) {
    protocolError = false;
    protocolErrorFilled = false;
    displayDirty = true;
    Serial.printf("snapshot duplicate revision=%s\n", candidate.revision.c_str());
    return;
  }
  if (animationActive) {
    queuedSnapshot = candidate;
    queuedSnapshotValid = true;
    protocolError = false;
    protocolErrorFilled = false;
    Serial.printf("snapshot queued latest revision=%s events=%u\n",
                  candidate.revision.c_str(), candidate.count);
    return;
  }
  acceptSnapshot(candidate, now);
}

void messageReceived(String &topic, String &payload) {
  if (topic != eventTopic) return;
  if (payload.length() > MAX_PAYLOAD_BYTES) {
    inboundPayload = "";
    inboundPending = false;
    inboundOversized = true;
    return;
  }
  inboundOversized = false;
  inboundPayload = payload;
  inboundPending = true;
}

void startWifiAttempt(uint32_t now) {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  wifiAttemptActive = true;
  wifiAttemptStartedAt = now;
  Serial.println(F("wifi connect attempt"));
  displayDirty = true;
}

void serviceWifi(uint32_t now) {
  bool connected = WiFi.status() == WL_CONNECTED;
  if (connected) {
    if (!previousWifiConnected) {
      Serial.print(F("wifi connected ip="));
      Serial.println(WiFi.localIP());
      displayDirty = true;
    }
    previousWifiConnected = true;
    wifiAttemptActive = false;
    wifiFailures = 0;
    return;
  }
  if (previousWifiConnected) {
    Serial.println(F("wifi disconnected"));
    displayDirty = true;
  }
  previousWifiConnected = false;
  if (wifiAttemptActive && now - wifiAttemptStartedAt >= WIFI_ATTEMPT_TIMEOUT_MS) {
    WiFi.disconnect();
    wifiAttemptActive = false;
    wifiFailures = isd::incrementFailure(wifiFailures);
    nextWifiAttemptAt = now + isd::nextBackoffMs(wifiFailures, ESP.getEfuseMac());
    Serial.printf("wifi retry scheduled failures=%u\n", wifiFailures);
  }
  if (!wifiAttemptActive && isd::timeReached(now, nextWifiAttemptAt)) startWifiAttempt(now);
}

String mqttClientId() {
  uint64_t chip = ESP.getEfuseMac();
  char buffer[32];
  snprintf(buffer, sizeof(buffer), "isd-%04X%08X", static_cast<uint16_t>(chip >> 32),
           static_cast<uint32_t>(chip));
  return String(buffer);
}

void serviceMqtt(uint32_t now) {
  if (WiFi.status() != WL_CONNECTED) {
    if (mqtt.connected()) mqtt.disconnect();
    previousMqttConnected = false;
    return;
  }
  if (mqtt.connected()) {
    mqtt.loop();
    if (!previousMqttConnected) displayDirty = true;
    previousMqttConnected = true;
    everOnline = true;
    mqttFailures = 0;
    return;
  }
  if (previousMqttConnected) {
    Serial.println(F("mqtt disconnected"));
    displayDirty = true;
  }
  previousMqttConnected = false;
  if (!isd::timeReached(now, nextMqttAttemptAt)) return;
  String clientId = mqttClientId();
  Serial.print(F("mqtt connect attempt endpoint="));
  Serial.print(MQTT_HOST);
  Serial.print(':');
  Serial.print(MQTT_PORT);
  Serial.print(F(" local_ip="));
  Serial.println(WiFi.localIP());
  if (mqtt.connect(clientId.c_str(), MQTT_USERNAME, MQTT_PASSWORD)) {
    if (mqtt.subscribe(eventTopic, 1)) {
      Serial.print(F("mqtt subscribed topic="));
      Serial.println(eventTopic);
      displayDirty = true;
    } else {
      mqtt.disconnect();
      mqttFailures = isd::incrementFailure(mqttFailures);
      nextMqttAttemptAt = now + isd::nextBackoffMs(mqttFailures, ESP.getEfuseMac() >> 8);
      Serial.println(F("mqtt subscribe failed"));
    }
  } else {
    mqttFailures = isd::incrementFailure(mqttFailures);
    nextMqttAttemptAt = now + isd::nextBackoffMs(mqttFailures, ESP.getEfuseMac() >> 8);
    Serial.printf("mqtt retry scheduled failures=%u\n", mqttFailures);
  }
}

}  // namespace

void setup() {
  Serial.begin(115200);
  Wire.begin(SPRITE_SDA, SPRITE_SCL);
  spriteDisplay.setI2CAddress(OLED_ADDRESS << 1);
  spriteDisplay.setBusClock(400000);
  spriteDisplay.begin();
  spriteDisplay.enableUTF8Print();
  eventDisplay.setI2CAddress(OLED_ADDRESS << 1);
  eventDisplay.begin();
  eventDisplay.enableUTF8Print();
  Serial.println(F("displays ready sprite=hw-i2c:sda21:scl22 event=sw-i2c:sda25:scl26"));
  bootScreenUntil = millis() + BOOT_SCREEN_MS;
  spriteStateStartedAt = millis();
  renderCurrent(millis());
  serviceSprite(millis());

  if (!isd::validDeviceId(DEVICE_ID)) {
    Serial.println(F("fatal config: invalid DEVICE_ID"));
    while (true) delay(1000);
  }
  eventTopic = String("infoscope/v1/devices/") + DEVICE_ID + "/events";
  mqtt.begin(MQTT_HOST, MQTT_PORT, network);
  mqtt.onMessage(messageReceived);
  startWifiAttempt(millis());
}

void loop() {
  uint32_t now = millis();
  serviceWifi(now);
  serviceMqtt(now);
  processInbound(now);
  serviceAnimation(now);
  serviceSprite(now);

  if (protocolError && protocolErrorFilled &&
      isd::timeReached(now, protocolErrorFilledUntil)) {
    protocolErrorFilled = false;
    displayDirty = true;
  }
  if (displayDirty && !animationActive) renderCurrent(now);

  bool wifiConnected = WiFi.status() == WL_CONNECTED;
  bool mqttConnected = mqtt.connected();
  if (wifiConnected != previousWifiConnected || mqttConnected != previousMqttConnected) {
    displayDirty = true;
  }
  delay(2);
}
