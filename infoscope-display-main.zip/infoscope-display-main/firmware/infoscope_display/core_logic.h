#pragma once

#include <stddef.h>
#include <stdint.h>

namespace isd {

constexpr uint32_t BACKOFF_MAX_MS = 30000;

enum class SpriteState : uint8_t {
  BOOT,
  WIFI_CONNECTING,
  MQTT_CONNECTING,
  ONLINE,
  OFFLINE,
  PROTOCOL_ERROR,
};

enum class SpriteFrame : uint8_t {
  OPEN,
  BLINK,
  NOD,
  SHAKE_LEFT,
  SHAKE_RIGHT,
  ERROR,
};

constexpr char SPRITE_PIXELS[6][12][13] = {
    {"....####....", "...#....#...", "..#.#..#.#..", "..#......#..",
     "..#.#..#.#..", "..#......#..", "...#....#...", "....####....",
     ".....##.....", "....#..#....", "...#....#...", "............"},
    {"....####....", "...#....#...", "..#......#..", "..#.####.#..",
     "..#......#..", "..#......#..", "...#....#...", "....####....",
     ".....##.....", "....#..#....", "...#....#...", "............"},
    {"............", "....####....", "...#....#...", "..#.#..#.#..",
     "..#......#..", "..#.#..#.#..", "..#......#..", "...#....#...",
     "....####....", ".....##.....", "....#..#....", "...#....#..."},
    {"...####.....", "..#....#....", ".#.#..#.#...", ".#......#...",
     ".#.#..#.#...", ".#......#...", "..#....#....", "...####.....",
     "....##......", "...#..#.....", "..#....#....", "............"},
    {".....####...", "....#....#..", "...#.#..#.#.", "...#.####.#.",
     "...#......#.", "...#.#..#.#.", "....#....#..", ".....####...",
     "......##....", ".....#..#...", "....#....#..", "............"},
    {"....####....", "...#....#...", "..#.#..#.#..", "..#.####.#..",
     "..#......#..", "..#.####.#..", "...#....#...", "....####....",
     ".....##.....", "....####....", "...#....#...", "............"},
};

inline SpriteFrame spriteFrameAt(SpriteState state, uint32_t elapsedMs) {
  if (state == SpriteState::OFFLINE) return SpriteFrame::BLINK;
  if (state == SpriteState::PROTOCOL_ERROR) return SpriteFrame::ERROR;
  if (state == SpriteState::ONLINE) {
    uint32_t phase = elapsedMs % 4950UL;
    if (phase < 2200UL) return SpriteFrame::OPEN;
    if (phase < 2300UL) return SpriteFrame::BLINK;
    if (phase < 4650UL) return SpriteFrame::OPEN;
    if (phase < 4800UL) return SpriteFrame::NOD;
    return SpriteFrame::OPEN;
  }
  uint32_t phase = elapsedMs % 1000UL;
  if (phase < 50UL) return SpriteFrame::SHAKE_LEFT;
  if (phase < 100UL) return SpriteFrame::OPEN;
  if (phase < 150UL) return SpriteFrame::SHAKE_RIGHT;
  return SpriteFrame::OPEN;
}

inline bool timeReached(uint32_t now, uint32_t deadline) {
  return static_cast<int32_t>(now - deadline) >= 0;
}

inline uint32_t nextBackoffMs(uint8_t failures, uint32_t salt) {
  uint8_t shift = failures < 5 ? failures : 5;
  uint32_t delayMs = 1000UL << shift;
  if (delayMs > BACKOFF_MAX_MS) delayMs = BACKOFF_MAX_MS;
  uint32_t jitter = (salt + static_cast<uint32_t>(failures) * 997UL) % 501UL;
  uint32_t result = delayMs + jitter;
  return result < BACKOFF_MAX_MS ? result : BACKOFF_MAX_MS;
}

inline uint8_t incrementFailure(uint8_t failures) {
  return failures == UINT8_MAX ? UINT8_MAX : static_cast<uint8_t>(failures + 1);
}

inline bool validCalendarDate(uint16_t year, uint8_t month, uint8_t day) {
  if (year == 0 || month == 0 || month > 12 || day == 0) return false;
  constexpr uint8_t daysPerMonth[] = {31, 28, 31, 30, 31, 30,
                                      31, 31, 30, 31, 30, 31};
  uint8_t maximumDay = daysPerMonth[month - 1];
  bool leapYear = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
  if (month == 2 && leapYear) maximumDay = 29;
  return day <= maximumDay;
}

inline bool validDeviceId(const char *value) {
  size_t length = 0;
  while (value[length] != '\0') ++length;
  if (length == 0 || length > 64) return false;
  for (size_t index = 0; index < length; ++index) {
    char character = value[index];
    bool valid = (character >= 'A' && character <= 'Z') ||
                 (character >= 'a' && character <= 'z') ||
                 (character >= '0' && character <= '9') || character == '_' ||
                 character == '-';
    if (!valid || (index == 0 && (character == '_' || character == '-'))) return false;
  }
  return true;
}

}  // namespace isd
