# A1 hardware acceptance record

Status: **dual-display physical acceptance passed — pending Alan review and merge**
Date: 2026-08-18 (Asia/Shanghai)

## Hardware and build evidence

| Check | Evidence | Result |
| --- | --- | --- |
| Board | ESP32-D0WD-V3 revision 3.1; MAC recorded locally, not required by Contract | Pass |
| Display wiring | sprite SSD1306 `0x3C` on hardware SDA 21/SCL 22; Event SSD1306 `0x3C` on software SDA 25/SCL 26 | Initialized; visual check pending |
| Compile | 974,229 / 1,310,720 flash bytes (74%); 53,584 / 327,680 global RAM bytes (16%) | Pass |
| Upload | esptool upload and flash hash verification on `/dev/ttyUSB0` | Pass |
| Host suite | 55 tests; Contract, simulator, broker integration, six sprite matrices/timing, dual-bus mapping, firmware core, secure local setup, physical-scenario helpers | Pass |
| Static checks | Ruff and `git diff --check` | Pass |

## Physical observations

- The primary adapter remains connected to `yhwifi`; a secondary USB adapter hosts 2.4 GHz `ISD-LAB` at `10.42.0.1` without interrupting development connectivity.
- ESP32 receives `10.42.0.189`, authenticates as the device account, subscribes only to its device topic, receives QoS 1 messages, and sends PUBACK.
- A retained 277-byte canonical fixture is delivered on connection. Repeating its revision logs `snapshot duplicate` and does not start an animation.
- Two revisions sent 80 ms apart log the middle revision as animated and retain only `hardware-latest` as the queued snapshot.
- Malformed JSON and a 4097-byte payload are rejected without disconnect or reboot. An exactly 4096-byte valid payload with 12 Events is accepted.
- Unsupported glyph input emits one bounded rendering warning and is replaced defensively; empty and three-title snapshots are accepted.
- A normal broker stop produces bounded device retries. Restart reloads persistence, the device reauthenticates/resubscribes, and retained `hardware-latest` is delivered without duplicate animation.
- Stopping only the USB AP produces Wi-Fi loss and bounded retries. Restoring it reconnects Wi-Fi/MQTT and restores retained state.
- Hard reset boots from flash, reconnects, and logs `snapshot accepted ... first=true`, proving first retained render does not animate.
- Final dual-display firmware logs the frozen bus initialization and transitions `protocol_error → online` after invalid/valid payload recovery, then `offline → online` across a normal broker restart.
- The Event renderer accepts empty, three-title, unsupported-glyph, exactly 4096-byte, malformed, oversized, and latest-wins sequences while the device continues MQTT keepalive traffic.

## A1.6 case still required

- Human confirmation has passed for the two physical OLEDs: boot/connecting, empty, three-title, transition, offline/protocol-error states, readable Chinese/English/numeric rows, sprite motion, and no flash or residual frames.

Do not weaken authentication, expose Mosquitto publicly, self-approve, merge, or create `a1-hardware-verified` until Alan approves the completed record and PR #7 is merged.
